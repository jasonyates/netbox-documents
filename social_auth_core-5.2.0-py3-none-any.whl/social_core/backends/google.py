"""
Google OpenId, OAuth2, and OAuth1 backends, docs at:
    https://python-social-auth.readthedocs.io/en/latest/backends/google.html
"""

from typing import Any, Literal

from social_core.backends.base import BaseAuth

from .oauth import BaseOAuth1, BaseOAuth2


class BaseGoogleAuth(BaseAuth):
    ID_KEY = "email"

    def get_user_id(self, details, response):
        """Use google email as unique id"""
        if self.setting("ID_KEY"):
            return super().get_user_id(details, response)
        if self.setting("USE_UNIQUE_USER_ID", False):
            if "sub" in response:
                return response["sub"]
            return response["id"]
        return details["email"]

    def get_user_details(self, response):
        """Return user details from Google API account"""
        email = response.get("email", "")

        name, given_name, family_name = (
            response.get("name", ""),
            response.get("given_name", ""),
            response.get("family_name", ""),
        )

        fullname, first_name, last_name = self.get_user_names(
            name, given_name, family_name
        )
        return {
            "username": email.split("@", 1)[0],
            "email": email,
            "fullname": fullname,
            "first_name": first_name,
            "last_name": last_name,
        }


class BaseGoogleOAuth2API(BaseGoogleAuth):
    def user_data(self, access_token: str, *args, **kwargs) -> dict[str, Any] | None:
        """Return user data from Google API"""
        return self.get_json(
            "https://www.googleapis.com/oauth2/v3/userinfo",
            headers={
                "Authorization": f"Bearer {access_token}",
            },
        )

    def revoke_token_params(self, token, uid):
        return {"token": token}

    def revoke_token_headers(self, token, uid):
        return {"Content-type": "application/json"}


class GoogleOAuth2(BaseGoogleOAuth2API, BaseOAuth2):
    """Google OAuth2 authentication backend"""

    name = "google-oauth2"
    REDIRECT_STATE = False
    AUTHORIZATION_URL = "https://accounts.google.com/o/oauth2/auth"
    ACCESS_TOKEN_URL = "https://accounts.google.com/o/oauth2/token"
    REVOKE_TOKEN_URL = "https://accounts.google.com/o/oauth2/revoke"
    REVOKE_TOKEN_METHOD: Literal["GET", "POST", "DELETE"] = "GET"
    # The order of the default scope is important
    DEFAULT_SCOPE = ["openid", "email", "profile"]
    EXTRA_DATA = [
        ("refresh_token", "refresh_token", True),
        ("expires_in", "expires_in"),
        ("token_type", "token_type", True),
    ]


class GoogleOAuth(BaseGoogleAuth, BaseOAuth1):
    """Google OAuth authorization mechanism"""

    name = "google-oauth"
    AUTHORIZATION_URL = "https://www.google.com/accounts/OAuthAuthorizeToken"
    REQUEST_TOKEN_URL = "https://www.google.com/accounts/OAuthGetRequestToken"
    ACCESS_TOKEN_URL = "https://www.google.com/accounts/OAuthGetAccessToken"
    DEFAULT_SCOPE = ["https://www.googleapis.com/auth/userinfo#email"]

    def user_data(self, access_token: dict, *args, **kwargs) -> dict[str, Any] | None:
        """Return user data from Google API"""
        return self.get_querystring(
            "https://www.googleapis.com/userinfo/email",
            auth=self.oauth_auth(access_token),
        )

    def get_key_and_secret(self):
        """
        Return Google OAuth Consumer Key and Consumer Secret pair

        Uses anonymous by default, beware that this marks the application as
        not registered and a security badge is displayed on authorization page.
        https://developers.google.com/identity/protocols/oauth2
        """
        key_secret = super().get_key_and_secret()
        if key_secret == (None, None):
            key_secret = ("anonymous", "anonymous")
        return key_secret
