"""
Auth0 implementation based on:
https://auth0.com/docs/quickstart/webapp/django/01-login
"""

import jwt

from social_core.exceptions import AuthTokenError

from .oauth import BaseOAuth2


class Auth0OAuth2(BaseOAuth2):
    """Auth0 OAuth authentication backend"""

    name = "auth0"
    ID_KEY = "user_id"
    DEFAULT_SCOPE = ["openid", "profile", "email"]
    SCOPE_SEPARATOR = " "
    EXTRA_DATA = [("picture", "picture")]

    def api_path(self, path="") -> str:
        """Build API path for Auth0 domain"""
        return f"https://{self.setting('DOMAIN')}/{path}"

    def authorization_url(self):
        return self.api_path("authorize")

    def access_token_url(self):
        return self.api_path("oauth/token")

    def get_user_id(self, details, response):
        """Return current user id."""
        return self.get_user_id_from_sources(details)

    def get_user_details(self, response):
        # Obtain JWT and the keys to validate the signature
        id_token = response.get("id_token")
        if id_token is None:
            raise AuthTokenError(self, "Missing id_token in Auth0 token response")
        jwks = self.get_json(self.api_path(".well-known/jwks.json"))
        issuer = self.api_path()
        audience = self.setting("KEY")  # CLIENT_ID
        try:
            try:
                # it could be a set of JWKs
                keys = jwt.PyJWKSet.from_dict(jwks).keys
            except jwt.PyJWKSetError:
                # try to get single JWK
                keys = [jwt.PyJWK.from_dict(jwks, "RS256")]
        except jwt.PyJWTError as error:
            raise AuthTokenError(self, error) from error

        signature_error = None
        for key in keys:
            try:
                payload = jwt.decode(
                    id_token,
                    key.key,
                    algorithms=["RS256"],
                    audience=audience,
                    issuer=issuer,
                )
            except (jwt.InvalidSignatureError, jwt.InvalidAlgorithmError) as ex:
                signature_error = ex
            except jwt.PyJWTError as error:
                raise AuthTokenError(self, error) from error
            else:
                break
        else:
            assert signature_error is not None
            # raise the last exception found during iteration
            raise AuthTokenError(self, signature_error) from signature_error

        fullname, first_name, last_name = self.get_user_names(payload["name"])
        details = {
            "username": payload["nickname"],
            "email": payload["email"],
            "email_verified": payload.get("email_verified", False),
            "fullname": fullname,
            "first_name": first_name,
            "last_name": last_name,
            "picture": payload["picture"],
            "user_id": payload["sub"],
        }
        id_key = self.id_key()
        if id_key not in details:
            user_id = payload.get(id_key)
            if user_id is None:
                raise AuthTokenError(self, f"Missing configured user ID claim {id_key}")
            details[id_key] = user_id
        return details
