"""
SurveyMonkey OAuth2 backend, docs at:
    https://developer.surveymonkey.com/api/v3/#authentication
"""

from typing import Any

from .oauth import BaseOAuth2


class SurveyMonkeyOAuth2(BaseOAuth2):
    """SurveyMonkey OAuth2 authentication backend"""

    name = "surveymonkey"
    AUTHORIZATION_URL = "https://api.surveymonkey.com/oauth/authorize"
    ACCESS_TOKEN_URL = "https://api.surveymonkey.com/oauth/token"
    USER_DATA_URL = "/v3/users/me"
    STATE_PARAMETER = True
    REDIRECT_STATE = False
    EXTRA_DATA = [
        ("access_url", "access_url"),
    ]

    def get_user_details(self, response):
        """Return user details from a SurveyMonkey /users/me response"""
        response["name"] = f"{response['first_name']} {response['last_name']}"
        return response

    def user_data(self, access_token: str, *args, **kwargs) -> dict[str, Any] | None:
        """Loads user data information from service"""
        base_url = kwargs["response"]["access_url"]
        return self.get_json(
            base_url + self.USER_DATA_URL,
            headers={"Authorization": f"bearer {access_token}"},
        )
