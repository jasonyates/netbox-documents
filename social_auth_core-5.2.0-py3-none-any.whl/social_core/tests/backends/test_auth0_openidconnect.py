import json

import responses

from social_core.exceptions import AuthMissingParameter
from social_core.tests.backends.oauth import BaseAuthUrlTestMixin
from social_core.tests.backends.open_id_connect import OpenIdConnectTest


class Auth0OpenIdConnectTest(OpenIdConnectTest, BaseAuthUrlTestMixin):
    backend_path = "social_core.backends.auth0_openidconnect.Auth0OpenIdConnectAuth"
    domain = "example.auth0.com"
    issuer = f"https://{domain}/"
    user_id = "auth0|123456789"

    openid_config_body = json.dumps(
        {
            "issuer": issuer,
            "authorization_endpoint": f"https://{domain}/authorize",
            "token_endpoint": f"https://{domain}/oauth/token",
            "userinfo_endpoint": f"https://{domain}/userinfo",
            "revocation_endpoint": f"https://{domain}/oauth/revoke",
            "jwks_uri": f"https://{domain}/.well-known/jwks.json",
        }
    )

    expected_username = "testuser"

    def extra_settings(self):
        settings = super().extra_settings()
        settings.update(
            {
                "SOCIAL_AUTH_AUTH0_OPENIDCONNECT_DOMAIN": self.domain,
                "SOCIAL_AUTH_AUTH0_OPENIDCONNECT_USERNAME_KEY": "nickname",
            }
        )
        return settings

    def pre_complete_callback(self, start_url) -> None:
        self.access_token_kwargs.setdefault("subject", self.user_id)
        super().pre_complete_callback(start_url)

        # Mock userinfo response with Auth0-specific fields
        responses.add(
            "GET",
            url=self.backend.userinfo_url(),
            status=200,
            body=json.dumps(
                {
                    "nickname": self.expected_username,
                    "email": "test@example.com",
                    "email_verified": True,
                    "picture": "https://example.com/avatar.jpg",
                    "locale": "en-US",
                    "sub": self.user_id,
                    "name": "Test User",
                    "given_name": "Test",
                    "family_name": "User",
                }
            ),
            content_type="application/json",
        )

    def get_id_token(self, *args, **kwargs):
        id_token = super().get_id_token(*args, **kwargs)
        id_token["custom_id"] = "token-only-identifier"
        return id_token

    def test_domain_configuration(self) -> None:
        """Test that domain-based URLs are constructed correctly"""
        self.assertEqual(
            self.backend.authorization_url(), f"https://{self.domain}/authorize"
        )
        self.assertEqual(
            self.backend.access_token_url(), f"https://{self.domain}/oauth/token"
        )

    def test_api_path_normalizes_domain_with_trailing_slash(self) -> None:
        self.strategy.set_settings(
            {"SOCIAL_AUTH_AUTH0_OPENIDCONNECT_DOMAIN": f"{self.domain}/"}
        )

        self.assertEqual(self.backend.api_path(), f"https://{self.domain}")
        self.assertEqual(
            self.backend.api_path("/oauth/token/"),
            f"https://{self.domain}/oauth/token",
        )
        self.assertEqual(self.backend.oidc_endpoint(), f"https://{self.domain}")

    def test_api_path_normalizes_domain_with_scheme(self) -> None:
        self.strategy.set_settings(
            {"SOCIAL_AUTH_AUTH0_OPENIDCONNECT_DOMAIN": f"https://{self.domain}/"}
        )

        self.assertEqual(self.backend.api_path(), f"https://{self.domain}")
        self.assertEqual(
            self.backend.api_path("/authorize"),
            f"https://{self.domain}/authorize",
        )
        self.assertEqual(self.backend.oidc_endpoint(), f"https://{self.domain}")

    def test_api_path_rejects_missing_domain(self) -> None:
        self.strategy.set_settings({"SOCIAL_AUTH_AUTH0_OPENIDCONNECT_DOMAIN": ""})

        with self.assertRaises(AuthMissingParameter):
            self.backend.api_path()

    def test_api_path_rejects_missing_domain_after_normalization(self) -> None:
        self.strategy.set_settings({"SOCIAL_AUTH_AUTH0_OPENIDCONNECT_DOMAIN": "/"})
        with self.assertRaises(AuthMissingParameter):
            self.backend.api_path()

    def test_oidc_config_uses_correct_discovery_url(self) -> None:
        self.backend.oidc_config.invalidate()
        self.backend.oidc_config()

        self.assertEqual(
            responses.calls[-1].request.url,
            f"https://{self.domain}/.well-known/openid-configuration",
        )

    def test_oidc_config_uses_correct_discovery_url_with_normalized_domain(
        self,
    ) -> None:
        self.strategy.set_settings(
            {"SOCIAL_AUTH_AUTH0_OPENIDCONNECT_DOMAIN": f"https://{self.domain}/"}
        )
        self.backend.oidc_config.invalidate()
        self.backend.oidc_config()

        self.assertEqual(
            responses.calls[-1].request.url,
            f"https://{self.domain}/.well-known/openid-configuration",
        )

    def test_auth0_user_details(self) -> None:
        """Test Auth0-specific user detail extraction"""
        response = {
            "nickname": "testuser",
            "email": "test@example.com",
            "email_verified": True,
            "picture": "https://example.com/avatar.jpg",
            "locale": "en-US",
            "sub": self.user_id,
            "name": "Test User",
            "given_name": "Test",
            "family_name": "User",
        }

        details = self.backend.get_user_details(response)

        self.assertEqual(details["username"], "testuser")
        self.assertEqual(details["email"], "test@example.com")
        self.assertTrue(details["email_verified"])
        self.assertEqual(details["picture"], "https://example.com/avatar.jpg")
        self.assertEqual(details["user_id"], self.user_id)

    def test_auth0_user_id_uses_id_token_sub(self) -> None:
        self.backend.id_token = {"sub": "validated-subject"}
        details = self.backend.get_user_details({"sub": self.user_id})

        self.assertEqual(details["user_id"], "validated-subject")
        self.assertEqual(
            self.backend.get_user_id(details, {"sub": self.user_id}),
            "validated-subject",
        )

    def test_configured_user_id_uses_id_token_claim(self) -> None:
        self.strategy.set_settings(
            {"SOCIAL_AUTH_AUTH0_OPENIDCONNECT_ID_KEY": "custom_id"}
        )

        user = self.do_login()

        self.assertEqual(user.social[0].uid, "token-only-identifier")

    def test_everything_works(self) -> None:
        self.do_login()
