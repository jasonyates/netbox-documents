import json
from unittest.mock import patch

import jwt
import responses

from social_core.exceptions import AuthTokenError
from social_core.utils import get_querystring

from .oauth import BaseAuthUrlTestMixin, OAuth2Test

JWK_KEY = {
    "kty": "RSA",
    "d": "ZmswNokEvBcxW_Kvcy8mWUQOQCBdGbnM0xR7nhvGHC-Q24z3XAQWlMWbsmGc_R1o"
    "_F3zK7DBlc3BokdRaO1KJirNmnHCw5TlnBlJrXiWpFBtVglUg98-4sRRO0VWnGXK"
    "JPOkBQ6b_DYRO3b0o8CSpWowpiV6HB71cjXTqKPZf-aXU9WjCCAtxVjfIxgQFu5I"
    "-G1Qah8mZeY8HK_y99L4f0siZcbUoaIcfeWBhxi14ODyuSAHt0sNEkhiIVBZE7QZ"
    "m-SEP1ryT9VAaljbwHHPmg7NC26vtLZhvaBGbTTJnEH0ZubbN2PMzsfeNyoCIHy4"
    "4QDSpQDCHfgcGOlHY_t5gQ",
    "e": "AQAB",
    "use": "sig",
    "kid": "foobar",
    "alg": "RS256",
    "n": "pUfcJ8WFrVue98Ygzb6KEQXHBzi8HavCu8VENB2As943--bHPcQ-nScXnrRFAUg8"
    "H5ZltuOcHWvsGw_AQifSLmOCSWJAPkdNb0w0QzY7Re8NrPjCsP58Tytp5LicF0Ao"
    "Ag28UK3JioY9hXHGvdZsWR1Rp3I-Z3nRBP6HyO18pEgcZ91c9aAzsqu80An9X4DA"
    "b1lExtZorvcd5yTBzZgr-MUeytVRni2lDNEpa6OFuopHXmg27Hn3oWAaQlbymd4g"
    "ifc01oahcwl3ze2tMK6gJxa_TdCf1y99Yq6oilmVvZJ8kwWWnbPE-oDmOVPVnEyT"
    "vYVCvN4rBT1DQ-x0F1mo2Q",
}

JWK_PUBLIC_KEY = {key: value for key, value in JWK_KEY.items() if key != "d"}

DOMAIN = "foobar.auth0.com"


class Auth0OAuth2Test(OAuth2Test, BaseAuthUrlTestMixin):
    backend_path = "social_core.backends.auth0.Auth0OAuth2"
    access_token_body = json.dumps(
        {
            "access_token": "foobar",
            "token_type": "bearer",
            "expires_in": 86400,
            "id_token": jwt.encode(
                {
                    "nickname": "foobar",
                    "email": "foobar@auth0.com",
                    "name": "John Doe",
                    "picture": "http://example.com/image.png",
                    "sub": "123456",
                    "iss": f"https://{DOMAIN}/",
                    "aud": "a-key",
                },
                jwt.PyJWK(JWK_KEY).key,
                algorithm="RS256",
            ),
        }
    )
    expected_username = "foobar"
    jwks_url = "https://foobar.auth0.com/.well-known/jwks.json"

    def extra_settings(self):
        assert self.name, "Subclasses must set the name attribute"
        settings = super().extra_settings()
        settings[f"SOCIAL_AUTH_{self.name}_DOMAIN"] = DOMAIN
        return settings

    def auth_handlers(self, start_url):
        responses.add(
            responses.GET,
            self.jwks_url,
            body=json.dumps({"keys": [JWK_PUBLIC_KEY]}),
            content_type="application/json",
        )
        return super().auth_handlers(start_url)

    def test_login(self) -> None:
        self.do_login()

    def test_login_with_configured_token_claim_id(self) -> None:
        self.strategy.set_settings({"SOCIAL_AUTH_AUTH0_ID_KEY": "sub"})

        user = self.do_login()

        self.assertEqual(user.social[0].uid, "123456")

    def test_missing_configured_token_claim_raises_token_error(self) -> None:
        self.strategy.set_settings({"SOCIAL_AUTH_AUTH0_ID_KEY": "missing_claim"})

        with self.assertRaisesRegex(
            AuthTokenError,
            "Missing configured user ID claim missing_claim",
        ):
            self.do_login()

    def test_default_scope(self) -> None:
        self.assertEqual(
            get_querystring(self.backend.auth_url())["scope"],
            "openid profile email",
        )

    def test_custom_scope_is_combined_with_default_scope(self) -> None:
        self.strategy.set_settings({"SOCIAL_AUTH_AUTH0_SCOPE": ["custom"]})

        self.assertEqual(
            get_querystring(self.backend.auth_url())["scope"],
            "custom openid profile email",
        )

    def test_missing_id_token_raises_auth_token_error(self) -> None:
        with (
            patch.object(self.backend, "get_json") as get_json,
            self.assertRaisesRegex(
                AuthTokenError,
                "Token error: Missing id_token in Auth0 token response",
            ),
        ):
            self.backend.get_user_details({})

        get_json.assert_not_called()

    def test_invalid_signature_raises_auth_token_error(self) -> None:
        assert self.access_token_body is not None
        id_token = json.loads(self.access_token_body)["id_token"]
        header, payload, _signature = id_token.split(".")

        with (
            patch.object(
                self.backend, "get_json", return_value={"keys": [JWK_PUBLIC_KEY]}
            ),
            self.assertRaises(AuthTokenError) as context,
        ):
            self.backend.get_user_details({"id_token": f"{header}.{payload}.AAAA"})

        self.assertIsInstance(context.exception.__cause__, jwt.InvalidSignatureError)

    def test_invalid_jwk_raises_auth_token_error(self) -> None:
        assert self.access_token_body is not None
        id_token = json.loads(self.access_token_body)["id_token"]

        with (
            patch.object(self.backend, "get_json", return_value={}),
            self.assertRaises(AuthTokenError) as context,
        ):
            self.backend.get_user_details({"id_token": id_token})

        self.assertIsInstance(context.exception.__cause__, jwt.PyJWTError)

    def test_partial_pipeline(self) -> None:
        self.do_partial_pipeline()
