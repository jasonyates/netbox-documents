# Copyright (c) 2025-2026 Zensical and contributors

# SPDX-License-Identifier: MIT
# All contributions are certified under the DCO

# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to
# deal in the Software without restriction, including without limitation the
# rights to use, copy, modify, merge, publish, distribute, sublicense, and/or
# sell copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:

# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.

# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
# FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
# IN THE SOFTWARE.

from __future__ import annotations

import importlib.util
import logging
import platform
import subprocess
import traceback
from collections.abc import Callable, Iterable
from copy import copy, deepcopy
from dataclasses import asdict, dataclass, field
from datetime import datetime
from functools import cache
from html import escape
from inspect import signature
from pathlib import Path
from typing import TYPE_CHECKING, Any, Literal, TypeAlias
from urllib.parse import urlparse

import jinja2
import yaml
from click import echo, style
from jinja2.exceptions import UndefinedError
from jinja2.loaders import split_template_path
from markdown import Extension
from markdown.preprocessors import Preprocessor
from pathspec import PathSpec
from pathspec.patterns.gitignore.spec import GitIgnoreSpecPattern

from zensical.extensions.context import ContextPreprocessor, Page
from zensical.extensions.table_reader import (
    _add_indentation,
    _convert_to_md_table,
    _get_table_readers,
)

if TYPE_CHECKING:
    from jinja2 import Environment
    from markdown import Markdown


# -----------------------------------------------------------------------------
# Constants
# -----------------------------------------------------------------------------


_LOGGER = logging.getLogger(__name__)

VariablesType: TypeAlias = dict[str, Any]
MacrosType: TypeAlias = dict[str, Callable[..., Any]]
FiltersType: TypeAlias = dict[str, Callable[..., Any]]
VariablesMacrosFiltersType: TypeAlias = tuple[
    VariablesType, MacrosType, FiltersType
]

_MACROS_INFO = """
{#
Template for the macro_info() command
(C) Laurent Franceschetti 2019
#}

## Macros Plugin Environment

### General List

All available variables and filters within the macros plugin:

{{ context() | pretty }}

### Config Information

Standard configuration information. Do not try to modify.

e.g. {{ "`{{ config.docs_dir }}`" }}

See also the [MkDocs documentation on the config object](https://www.MkDocs.org/user-guide/custom-themes/#config).

{{ context(config)| pretty }}

### Macros

These macros have been defined programmatically for this environment
(module or pluglets).

{{ context(macros)| pretty }}

### Git Information

Information available on the last commit and the git repository containing the
documentation project:

e.g. {{ "`{{ git.message }}`" }}

{{ context(git)| pretty }}

### Page Attributes

Provided by MkDocs. These attributes change for every page
(the attributes shown are for this page).

e.g. {{ "`{{ page.title }}`" }}

See also the [MkDocs documentation on the page object](https://www.MkDocs.org/user-guide/custom-themes/#page).

{{ context(page)| pretty }}

To have all titles of all pages, use:

    {% raw %}
    {% for page in navigation.pages %}
    - {{ page.title }}
    {% endfor %}
    {% endraw %}


### Plugin Filters

These filters are provided as a standard by the macros plugin.

{{ context(filters)| pretty }}

### Builtin Jinja2 Filters

These filters are provided by Jinja2 as a standard.

See also the [Jinja2 documentation on builtin filters](https://jinja.palletsprojects.com/en/3.1.x/templates/#builtin-filters).

{{ context(filters_builtin) | pretty }}
"""


# -----------------------------------------------------------------------------
# Classes
# -----------------------------------------------------------------------------


class _MacroVariables(dict[str, Any]):
    """Macro variables are exposed through keys and attributes.

    Nested dictionaries and lists are converted during construction and updates.
    Values assigned directly are retained, as in MkDocs Macros.
    """

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)
        for key, value in self.items():
            self[key] = _macro_value(value)

    def update(self, *args: Any, **kwargs: Any) -> None:
        if (
            len(args) == 1
            and isinstance(args[0], _MacroVariables)
            and not kwargs
        ):
            super().update(args[0])
        else:
            super().update(_MacroVariables(*args, **kwargs))

    def __getattr__(self, name: str) -> Any:
        try:
            return self[name]
        except KeyError as error:
            raise AttributeError(name) from error

    def __setattr__(self, name: str, value: Any) -> None:
        self[name] = value

    def __delattr__(self, name: str) -> None:
        try:
            del self[name]
        except KeyError as error:
            raise AttributeError(name) from error


class _MacroList(list[Any]):
    """Dot access is provided for dictionaries nested inside variable lists."""

    def __init__(self, values: Iterable[Any] = ()) -> None:
        super().__init__(_macro_value(value) for value in values)

    def extend(self, values: Iterable[Any]) -> None:
        super().extend(_MacroList(values))

    def __add__(self, values: list[Any]) -> _MacroList:
        return _MacroList(super().__add__(_MacroList(values)))


class _LaxUndefined(jinja2.Undefined):
    """Missing attributes are rendered as empty strings, as in MkDocs Macros."""

    def _fail_with_undefined_error(self, *_args: Any, **_kwargs: Any) -> str:  # ty:ignore[invalid-method-override]
        return ""


class MacroEnv:
    """Minimal env object for compatibility with MkDocs Macros."""

    def __init__(
        self,
        conf: dict[str, Any] | None = None,
        *,
        config: dict[str, Any] | None = None,
        page: Page | None = None,
        verbose: bool = False,
    ) -> None:
        self.conf = conf if conf is not None else {}
        self.config = config if config is not None else {}
        self.page = page
        self.project_dir = str(Path(self.conf.get("root_dir", ".")).resolve())
        self._verbose = verbose
        self.variables = _MacroVariables()
        self.macros: MacrosType = {}
        self.filters: FiltersType = {}

    def start_chatting(
        self, prefix: str, color: str = "yellow"
    ) -> Callable[..., None]:
        """Create a module logger enabled by the plugin's verbose setting."""

        def chatter(*args: Any) -> None:
            if not self._verbose:
                return
            label = f"[macros - {prefix}] -"
            message = " ".join(str(arg) for arg in args)
            if _LOGGER.hasHandlers():
                _LOGGER.info("%s %s", label, message)
            else:
                # The native CLI does not configure Python logging handlers.
                echo(f"{style(label, fg=color)} {message}", err=True)

        return chatter

    def macro(
        self, fn: Callable[..., Any] | None = None, name: str | None = None
    ) -> Any:
        """Register a macro.

        Use as `@env.macro` or `env.macro(func)` or `env.macro(func, 'name')`.
        """
        if fn is None:
            return lambda f: self.macro(f, name)
        self.macros[name or fn.__name__] = fn  # ty:ignore[unresolved-attribute]
        return fn

    def filter(
        self, fn: Callable[..., Any] | None = None, name: str | None = None
    ) -> Any:
        """Register a filter.

        Use as `@env.filter` or `env.filter(func)`.
        """
        if fn is None:
            return lambda f: self.filter(f, name)
        self.filters[name or fn.__name__] = fn  # ty:ignore[unresolved-attribute]
        return fn


@dataclass
class MacrosConfig:
    """Configuration for the macros Markdown extension."""

    module_name: str = "main"
    modules: list[str] = field(default_factory=list)
    include_yaml: list[str] | dict[str, str] = field(default_factory=list)
    include_dir: str = ""
    render_by_default: bool = True
    force_render_paths: str = ""
    on_error_fail: bool = False
    on_undefined: Literal["keep", "silent", "strict", "lax"] = "keep"
    verbose: bool = False
    j2_block_start_string: str = "{%"
    j2_block_end_string: str = "%}"
    j2_variable_start_string: str = "{{"
    j2_variable_end_string: str = "}}"
    j2_comment_start_string: str = "{#"
    j2_comment_end_string: str = "#}"
    j2_extensions: list[str] = field(default_factory=list)


class MacrosPreprocessor(Preprocessor):
    """Build Jinja2 context, render body."""

    name = "macros"

    def __init__(
        self,
        md: Markdown,
        config: MacrosConfig,
    ) -> None:
        super().__init__(md)
        self.config = config
        # Use the pattern class behind upstream's deprecated gitwildmatch name.
        self._render_paths = PathSpec.from_lines(
            GitIgnoreSpecPattern, config.force_render_paths.splitlines()
        )

    def _should_render(self, page: Page | None) -> bool:
        """Page metadata and path selection apply before each rendering pass."""
        render_macros = page.meta.get("render_macros") if page else None
        if render_macros is False:
            return False
        return bool(
            self.config.render_by_default
            or render_macros
            or (page and self._render_paths.match_file(page.path))
        )

    def run(self, lines: list[str]) -> list[str]:
        """Render body as Jinja2 template with built context."""
        # Fetch rendering context from our context preprocessor
        context = ContextPreprocessor.from_markdown(self.md)
        page = context.page if context else None
        project_config = context.config if context else {}
        project_root = Path(project_config.get("root_dir", ".")).resolve()
        macros_env = MacroEnv(
            conf=project_config,
            config=asdict(self.config),
            page=page,
            verbose=self.config.verbose,
        )
        chatter = macros_env.start_chatting("render")
        page_path = page.path if page else "<string>"

        # Page metadata takes precedence over the default and path selection.
        if not self._should_render(page):
            chatter("Skipping page:", page_path)
            return lines
        chatter("Rendering page:", page_path)

        text = "\n".join(lines)
        variables: VariablesType = {}
        macro_variables = macros_env.variables
        macros: dict[str, Any] = macros_env.macros
        filters: dict[str, Callable] = {
            "pretty": _pretty,
            "fix_url": _fix_url,
            "add_indentation": _add_indentation,
            "convert_to_md_table": _convert_to_md_table,
        }

        # Mutable values are isolated from the configuration and other pages.
        extra = deepcopy(project_config.get("extra") or {})
        macro_variables["extra"] = extra
        macro_variables["config"] = project_config.copy()

        # Load YAML from configuration
        _merge_include_yaml(
            self.config.include_yaml,
            project_root,
            macro_variables,
        )

        # Load YAML data from page metadata
        if page:
            _merge_include_yaml(
                page.meta.get("include_yaml", []),
                project_root,
                macro_variables,
            )

        # Build Jinja2 environment
        env_kw: dict[str, Any] = {
            "block_start_string": self.config.j2_block_start_string,
            "block_end_string": self.config.j2_block_end_string,
            "variable_start_string": self.config.j2_variable_start_string,
            "variable_end_string": self.config.j2_variable_end_string,
            "undefined": _UNDEFINED_TYPES[self.config.on_undefined],
        }
        if self.config.j2_comment_start_string is not None:
            env_kw["comment_start_string"] = self.config.j2_comment_start_string
        if self.config.j2_comment_end_string is not None:
            env_kw["comment_end_string"] = self.config.j2_comment_end_string
        if self.config.j2_extensions:
            env_kw["extensions"] = self.config.j2_extensions

        include_dir = self.config.include_dir or project_config.get(
            "docs_dir", "docs"
        )
        env_kw["loader"] = _make_include_loader(project_root / include_dir)

        env = jinja2.Environment(**env_kw)  # noqa: S701

        # Store builtin Jinja filters before adding our own
        builtin_filters = env.filters.copy()

        # Standard variables are defined before extra and module overrides.
        standard_variables: dict[str, Any] = {
            "environment": _get_env_info(),
            "files": [],
            "filters": filters,
            "filters_builtin": builtin_filters,
            "git": _get_git_info(),
            "macros": macros,
            "navigation": [],
            "plugin": macros_env.config,
        }
        template_page = copy(page) if page else None
        macros.update({"context": _context_closure(variables), "now": _now})

        table_reader = (
            project_config.get("plugins", {})
            .get("table-reader", {})
            .get("config", {})
        )
        if not table_reader or not table_reader.get("enabled", True):
            table_reader = {}
        macros.update(
            _get_table_readers(
                project_root,
                docs_dir=project_config.get("docs_dir", "docs"),
                page_path=page.path if page else None,
                data_path=table_reader.get("data_path", "."),
                allow_missing_files=table_reader.get(
                    "allow_missing_files", False
                ),
            )
        )

        # Configured variables and context are available
        # during module registration.
        for name, value in standard_variables.items():
            macro_variables[name] = value
        macro_variables.update(extra)
        if template_page:
            macro_variables["page"] = template_page

        # Installed modules are loaded in order,
        # with the local module loaded last.
        for plug in self.config.modules:
            _load_module(macros_env, plug)
        if self.config.module_name:
            _load_module(macros_env, self.config.module_name, project_root)

        filters.update(macros_env.filters)
        env.filters.update(filters)

        # Diagnostics are created after all custom filters have been registered.
        macros.setdefault("macros_info", _macros_info_closure(env, variables))
        env.globals.update(macros)

        macro_variables["macros"] = macros.copy()
        macro_variables["filters"] = filters.copy()
        macro_variables["filters_builtin"] = builtin_filters
        if template_page:
            macro_variables["page"] = template_page

        def render_template(source: str) -> str:
            if not self._should_render(template_page):
                return source

            # Variables changed by body macros are read again
            # when the title is rendered.
            variables.clear()
            variables.update(env.globals)
            variables.update(macro_variables)
            if template_page:
                variables.update(template_page.meta)
            try:
                return env.from_string(source).render(**variables)
            except Exception as error:
                if self.config.on_error_fail:
                    raise
                _LOGGER.warning(
                    "Macro rendering failed in %s: %s", page_path, error
                )
                return _format_rendering_error(error, source, page_path)

        rendered = render_template(text)

        # The effective title is rendered after the body;
        # source metadata is retained.
        delimiters = (
            env.variable_start_string,
            env.block_start_string,
            env.comment_start_string,
        )
        title = page.title if page else None
        if (
            page
            and isinstance(title, str)
            and any(delimiter in title for delimiter in delimiters)
        ):
            page.title = render_template(title)

        # A rendered metadata title is supplied to the theme
        # without changing macro context.
        metadata_title = page.meta.get("title") if page else None
        if (
            page
            and isinstance(metadata_title, str)
            and any(delimiter in metadata_title for delimiter in delimiters)
        ):
            page.rendered_metadata_title = (
                page.title
                if metadata_title == title
                else render_template(metadata_title)
            )
        return rendered.split("\n")


class MacrosExtension(Extension):
    """Jinja2 templating with variables, macros, and filters."""

    name = "zensical.extensions.macros"

    def __init__(self, **kwargs: Any) -> None:
        """Initialize the extension."""
        self._enabled: bool = kwargs.pop("enabled", True)
        self._kwargs: dict[str, Any] = kwargs

    def extendMarkdown(self, md: Markdown) -> None:
        """Register Markdown extension."""
        if not self._enabled:
            return
        md.registerExtension(self)
        config = MacrosConfig(**self._kwargs)
        preprocessor = MacrosPreprocessor(md, config)
        # Before pymdownx.superfences'
        # `fenced_code_block` (25) and `fenced_raw_block` (31.05)
        md.preprocessors.register(preprocessor, preprocessor.name, 35)


_UNDEFINED_TYPES = {
    "keep": jinja2.DebugUndefined,
    "silent": jinja2.Undefined,
    "strict": jinja2.StrictUndefined,
    "lax": _LaxUndefined,
}


# -----------------------------------------------------------------------------
# Functions
# -----------------------------------------------------------------------------


def _macro_value(value: Any) -> Any:
    if isinstance(value, (_MacroVariables, _MacroList)):
        return value
    if isinstance(value, dict):
        return _MacroVariables(value)
    if isinstance(value, list):
        return _MacroList(value)
    return value


def makeExtension(**kwargs: Any) -> MacrosExtension:
    """Register Markdown extension."""
    return MacrosExtension(**kwargs)


# -----------------------------------------------------------------------------


def _make_include_loader(root: Path) -> jinja2.FunctionLoader:
    """Create a loader that joins template names with native separators.

    Jinja joins filesystem search paths with POSIX separators. Windows
    extended-length paths require backslashes, so resolve each safe template
    component with `Path` instead.
    """

    def load(
        template: str,
    ) -> tuple[str, str, Callable[[], bool]] | None:
        path = root.joinpath(*split_template_path(template))
        try:
            source = path.read_text(encoding="utf-8")
            mtime = path.stat().st_mtime
        except OSError:
            return None

        def uptodate() -> bool:
            try:
                return path.stat().st_mtime == mtime
            except OSError:
                return False

        return source, str(path), uptodate

    return jinja2.FunctionLoader(load)


# -----------------------------------------------------------------------------


def _now() -> datetime:
    """Return current datetime (`datetime.now()`)."""
    return datetime.now()  # noqa: DTZ005


# -----------------------------------------------------------------------------


def _macros_info_closure(
    env: Environment, variables: VariablesType
) -> Callable[[], str]:
    new_env = jinja2.Environment()  # noqa: S701
    new_env.filters.update(env.filters)
    new_env.globals.update(env.globals)

    def macros_info() -> str:
        """Display info about the macros environment, for debugging purposes."""
        return new_env.from_string(_MACROS_INFO).render(**variables)

    return macros_info


# -----------------------------------------------------------------------------


def _format_rendering_error(
    error: Exception, source: str, page_path: str
) -> str:
    """A rendering diagnostic is returned as Markdown for the affected page."""
    if isinstance(error, jinja2.TemplateSyntaxError):
        lines = (
            error.source if error.source is not None else source
        ).splitlines()
        line = lines[error.lineno - 1] if 0 < error.lineno <= len(lines) else ""
        location = f"_File_: `{page_path}`"
        if error.filename:
            location += f"\n\n_Template_: `{error.filename}`"

        return (
            f"# _Macro Syntax Error_\n\n{location}\n\n_Line {error.lineno}_: "
            f"**{escape(error.message or str(error))}**\n\n"
            f"{_add_indentation(line, spaces=4)}"
        )

    return (
        f"# _Macro Rendering Error_\n\n_File_: `{page_path}`\n\n"
        f"_{type(error).__name__}_: {escape(str(error))}\n\n"
        f"{_add_indentation(traceback.format_exc(), spaces=4)}"
    )


# -----------------------------------------------------------------------------


def _fix_url(url: str) -> str:
    parsed = urlparse(url)
    if (not parsed.scheme) and parsed.path:
        return "../" + url
    return url


# -----------------------------------------------------------------------------


def _list_items(obj: Any) -> Iterable[tuple[str | int, Any]]:
    if isinstance(obj, Page):
        attributes = {
            key: value
            for key, value in vars(obj).items()
            if not key.startswith("_")
        }
        attributes["title"] = obj.title
        return sorted(attributes.items())
    try:
        return sorted(obj.items())
    except AttributeError:
        return sorted(obj.__dict__.items())
    except TypeError:
        return enumerate(list(obj))


def _format_value(value: Any) -> str:
    if callable(value):
        if doc := value.__doc__:
            doc = doc.strip().split("\n", 1)[0]
        else:
            return ""
        try:
            param_names = ", ".join(signature(value).parameters)
        except ValueError:
            return doc
        else:
            return f"(*{param_names}*)<br>{doc}" if param_names else doc
    elif isinstance(value, dict):
        r_list = []
        for key, val in _list_items(value):
            if isinstance(val, (int, float, str, list, dict)) or val is None:
                r_list.append(f"**{key}** = {val!r}")
            else:
                r_list.append(f"**{key}** [*{type(val).__name__}*]")
        return ", ".join(r_list)
    else:
        return repr(value)


def _context_closure(
    variables: dict[str, Any],
) -> Callable[[Any], list[tuple[Any, Any, str]]]:
    def context(obj: Any = None) -> list[tuple[Any, Any, str]]:
        """Display macros context (single object or all context)."""
        if obj is None:
            obj = variables
        try:
            return [
                (var, type(value).__name__, _format_value(value))
                for var, value in _list_items(obj)
            ]
        except UndefinedError as e:
            return [("*Error!*", type(e).__name__, str(e))]
        except AttributeError:
            # Not an object or dictionary (int, str, etc.)
            return [(obj, type(obj).__name__, repr(obj))]

    return context


# -----------------------------------------------------------------------------


def _make_table(
    rows: list[tuple[str, str, str]],
    header: tuple[str, str, str],
) -> str:
    def _escape_cell(value: str) -> str:
        return value.replace("|", r"\|")

    header_line = " | ".join(_escape_cell(item) for item in header)
    separator_line = " | ".join(["---"] * len(header))
    body_lines = [
        " | ".join(_escape_cell(str(item)) for item in row) for row in rows
    ]
    return "\n".join([header_line, separator_line, *body_lines])


def _pretty(var_list: list[Any]) -> str:
    if not var_list:
        return ""
    rows = [
        (
            f"**{var}**",
            f"*{var_type}*",
            content.replace("\n", "<br>"),
        )
        for var, var_type, content in var_list
    ]
    try:
        return _make_table(rows, ("Variable", "Type", "Content"))
    except Exception as error:  # noqa: BLE001
        return f"#{type(error).__name__}: {error}\n{traceback.format_exc()}"


# -----------------------------------------------------------------------------


def _load_module(
    env: MacroEnv, module_name: str, project_root: Path | None = None
) -> None:
    """Load a module by name (e.g. 'main')."""
    chatter = env.start_chatting("module")
    if project_root:
        for candidate in [
            project_root / f"{module_name}.py",
            project_root / module_name / "__init__.py",
        ]:
            if not candidate.exists() or not candidate.is_relative_to(
                project_root
            ):
                continue
            spec = importlib.util.spec_from_file_location(
                module_name, candidate
            )
            if spec and spec.loader:
                chatter("Loading local module:", candidate)
                mod = importlib.util.module_from_spec(spec)
                spec.loader.exec_module(mod)
                if hasattr(mod, "define_env"):
                    mod.define_env(env)
                    return
            break

    # Only try import for package-like names (no path separators or "..").
    if "/" in module_name or "\\" in module_name or ".." in module_name:
        return
    chatter("Importing module:", module_name)
    try:
        mod = importlib.import_module(module_name)
    except ModuleNotFoundError as error:
        # Only an absent default local module is optional.
        if (
            project_root is None
            or module_name != "main"
            or error.name != module_name
        ):
            raise
        chatter("Module unavailable:", module_name)
    else:
        if hasattr(mod, "define_env"):
            mod.define_env(env)


def _load_one_yaml(
    path: str,
    project_root: Path,
) -> VariablesType | None:
    """Load a single YAML file. Path must be relative to project root."""
    p = (
        (project_root / path).resolve()
        if not Path(path).is_absolute()
        else Path(path).resolve()
    )
    if not p.exists() or not p.is_relative_to(project_root):
        return None
    try:
        with open(p, encoding="utf-8") as f:
            data = yaml.safe_load(f)
    except (OSError, ValueError):
        return None
    else:
        return data if isinstance(data, dict) else None


def _merge_include_yaml(
    include_yaml: list[str] | dict[str, str],
    project_root: Path,
    variables: VariablesType,
) -> None:
    """Merge external data into variables."""
    if not include_yaml:
        return
    if isinstance(include_yaml, dict):
        for key, path in include_yaml.items():
            if data := _load_one_yaml(path, project_root):
                variables[key] = data
    else:
        for path in include_yaml:
            if data := _load_one_yaml(path, project_root):
                # Nested YAML values are retained,
                # as with upstream's direct assignments.
                for key, value in data.items():
                    variables[key] = value


@cache
def _get_git_info() -> dict[str, Any]:
    """Return Git metadata for the current repository."""
    commands: dict[str, tuple[str, ...]] = {
        "short_commit": ("git", "rev-parse", "--short", "HEAD"),
        "commit": ("git", "rev-parse", "HEAD"),
        "tag": ("git", "describe", "--tags"),
        # With --abbrev set to 0, git finds the nearest tag name without suffix
        "short_tag": ("git", "describe", "--tags", "--abbrev=0"),
        "author": ("git", "log", "-1", "--pretty=format:%an"),
        "author_email": ("git", "log", "-1", "--pretty=format:%ae"),
        "committer": ("git", "log", "-1", "--pretty=format:%cn"),
        "committer_email": (
            "git",
            "log",
            "-1",
            "--pretty=format:%ce",
        ),
        # %cI is strict ISO 8601 commit date
        "date_ISO": ("git", "log", "-1", "--pretty=format:%cI"),
        "message": ("git", "log", "-1", "--pretty=format:%B"),
        "raw": ("git", "log", "-1"),
        "root_dir": ("git", "rev-parse", "--show-toplevel"),
    }

    result: dict[str, Any] = {"status": False, "date": None}

    for field_name, git_command in commands.items():
        try:
            output = subprocess.check_output(  # noqa: S603
                git_command,
                text=True,
                stderr=subprocess.DEVNULL,
            ).strip()
        except FileNotFoundError as error:
            # Git executable not found, abort early.
            return {
                "status": False,
                "diagnosis": "Git command not found",
                "error": str(error),
                "date": None,
            }
        except subprocess.CalledProcessError as error:
            if error.returncode == 128:  # noqa: PLR2004
                # Usually means no git repo or no tags.
                result[field_name] = ""
            else:
                result[field_name] = (
                    f"# Cannot execute '{git_command}': {error}"
                )
        except Exception as error:  # noqa: BLE001
            result[field_name] = f"# Unexpected error '{git_command}': {error}"
        else:
            result[field_name] = output
            if field_name == "date_ISO":
                result["date"] = datetime.fromisoformat(output)
            result["status"] = True

    return result


@cache
def _get_env_info() -> dict[str, str]:
    sys_name = platform.system() or "<UNKNOWN>"
    sys_name = {"Darwin": "MacOs"}.get(sys_name, sys_name)
    return {
        "system": sys_name,
        "system_version": platform.release(),
        "python_version": platform.python_version(),
        "mkdocs_version": "1.6.1",
        "macros_plugin_version": "1.3.7",
        "jinja2_version": jinja2.__version__,
    }
