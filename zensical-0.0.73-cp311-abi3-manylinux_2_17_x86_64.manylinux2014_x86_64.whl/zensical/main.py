# Copyright (c) 2025-2026 Zensical and contributors

# SPDX-License-Identifier: MIT
# All contributions are certified under the DCO

# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to
# deal in the Software without restriction, including without limitation the
# rights to use, copy, modify, merge, publish, distribute, sublicense, and/or
# sell copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:

# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.

# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
# FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
# IN THE SOFTWARE.

from __future__ import annotations

import os
import shutil
from pathlib import Path
from typing import Any

import click
from click import ClickException

from zensical import build, serve, version

# ----------------------------------------------------------------------------
# Commands
# ----------------------------------------------------------------------------


@click.version_option(version=version(), message="%(version)s")
@click.group()
def cli() -> None:
    """Zensical - A modern static site generator."""


@cli.command(name="build")
@click.option(
    "-f",
    "--config-file",
    type=click.Path(exists=True),
    default=None,
    help="Path to config file.",
)
@click.option(
    "-c",
    "--clean",
    default=False,
    is_flag=True,
    help="Clean cache.",
)
@click.option(
    "-s",
    "--strict",
    default=False,
    is_flag=True,
    help="Enable strict mode - abort the build on warnings.",
)
def execute_build(config_file: str | None, **kwargs: Any) -> None:
    """Build a project."""
    if config_file is None:
        for file in ["zensical.toml", "mkdocs.yml", "mkdocs.yaml"]:
            if os.path.exists(file):
                config_file = file
                break
        else:
            raise ClickException("No config file found in the current folder.")

    # Build project in Rust runtime, calling back into Python when necessary,
    # e.g., to parse MkDocs configuration format or render Markdown
    build(os.path.abspath(config_file), kwargs)


@cli.command(name="serve")
@click.option(
    "-f",
    "--config-file",
    type=click.Path(exists=True),
    default=None,
    help="Path to config file.",
)
@click.option(
    "-a",
    "--dev-addr",
    metavar="<IP:PORT>",
    help="IP address and port (default: localhost:8000).",
)
@click.option(
    "-o",
    "--open",
    default=False,
    is_flag=True,
    help="Open preview in default browser.",
)
@click.option(
    "-s",
    "--strict",
    default=False,
    is_flag=True,
    help="Strict mode (currently unsupported).",
)
def execute_serve(config_file: str | None, **kwargs: Any) -> None:
    """Build and serve a project."""
    if config_file is None:
        for file in ["zensical.toml", "mkdocs.yml", "mkdocs.yaml"]:
            if os.path.exists(file):
                config_file = file
                break
        else:
            raise ClickException("No config file found in the current folder.")
    if kwargs.get("strict", False):
        print("Warning: Strict mode is currently unsupported.")

    # Build project in Rust runtime, calling back into Python when necessary,
    # e.g., to parse MkDocs configuration format or render Markdown
    serve(os.path.abspath(config_file), kwargs)


@cli.command(name="new")
@click.argument(
    "directory",
    type=click.Path(file_okay=False, dir_okay=True, writable=True),
    required=False,
)
def new_project(directory: str | None, **kwargs: Any) -> None:  # noqa: ARG001
    """Create a new template project in the current or given directory.

    The new command returns with an error if the path provided is not a
    directory or if it already contains a zensical.toml file. If other
    files that are part of the template exist then they will not be
    overwritten but the new command will succeed.
    """
    working_dir = Path.cwd() if directory is None else Path(directory).resolve()
    if working_dir.is_file():
        raise ClickException(f"{working_dir} must be a directory, not a file.")

    config_file = working_dir / "zensical.toml"
    if config_file.exists():
        raise ClickException(f"{config_file} already exists.")

    working_dir.mkdir(parents=True, exist_ok=True)

    package_dir = Path(__file__).resolve().parent
    bootstrap = package_dir / "bootstrap"

    for src_file in bootstrap.rglob("*"):
        if src_file.is_file():
            rel_path = src_file.relative_to(bootstrap)
            dest_file = working_dir / rel_path
            if not dest_file.exists():
                dest_file.parent.mkdir(parents=True, exist_ok=True)
                shutil.copyfile(src_file, dest_file)


# ----------------------------------------------------------------------------
# Program
# ----------------------------------------------------------------------------

if __name__ == "__main__":  # pragma: no cover
    cli()
