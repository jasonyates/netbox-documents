from io import BytesIO

from sorl.thumbnail.conf import settings
from sorl.thumbnail.engines.base import EngineBase

try:
    from PIL import Image, ImageDraw, ImageFile, ImageMode, ImageSequence
    from PIL.ImageFilter import GaussianBlur
except ImportError:
    import Image
    import ImageDraw
    import ImageFile
    import ImageMode
    import ImageSequence
try:
    import pillow_avif  # noqa: F401
except ImportError:
    pass

if hasattr(Image, 'Resampling'):
    ANTIALIAS = Image.Resampling.LANCZOS
else:
    ANTIALIAS = Image.ANTIALIAS
# Image.Transpose added in 9.1.0
if hasattr(Image, 'Transpose'):
    FLIP_LEFT_RIGHT = Image.Transpose.FLIP_LEFT_RIGHT
    FLIP_TOP_BOTTOM = Image.Transpose.FLIP_TOP_BOTTOM
else:
    FLIP_LEFT_RIGHT = Image.FLIP_LEFT_RIGHT
    FLIP_TOP_BOTTOM = Image.FLIP_TOP_BOTTOM
EXIF_ORIENTATION = 0x0112


def color_count(image):
    """ Return the number of color values in the input image --
        this is the number of pixels times the band count
        of the image.
    """
    mode_descriptor = ImageMode.getmode(image.mode)
    width, height = image.size
    return width * height * len(mode_descriptor.bands)


def histogram_entropy_py(image):
    """ Calculate the entropy of an images' histogram. """
    from math import fsum, log2
    histosum = float(color_count(image))
    histonorm = (histocol / histosum for histocol in image.histogram())
    return -fsum(p * log2(p) for p in histonorm if p != 0.0)


# Select the Pillow native histogram entropy function - if
# available - and fall back to the Python implementation:
histogram_entropy = getattr(Image.Image, 'entropy', histogram_entropy_py)


def round_corner(radius, fill):
    """Draw a round corner"""
    corner = Image.new('L', (radius, radius), 0)  # (0, 0, 0, 0))
    draw = ImageDraw.Draw(corner)
    draw.pieslice((0, 0, radius * 2, radius * 2), 180, 270, fill=fill)
    return corner


def round_rectangle(size, radius, fill):
    """Draw a rounded rectangle"""
    width, height = size
    rectangle = Image.new('L', size, 255)  # fill
    corner = round_corner(radius, 255)  # fill
    rectangle.paste(corner, (0, 0))
    rectangle.paste(corner.rotate(90),
                    (0, height - radius))  # Rotate the corner and paste it
    rectangle.paste(corner.rotate(180), (width - radius, height - radius))
    rectangle.paste(corner.rotate(270), (width - radius, 0))
    return rectangle


class Engine(EngineBase):
    def create(self, image, geometry, options):
        """
        An animated source written as GIF is thumbnailed frame by frame,
        returning the list of frames
        """
        if options['format'] != 'GIF' or not getattr(image, 'is_animated', False):
            return super().create(image, geometry, options)

        frames = []
        for frame in ImageSequence.Iterator(image):
            # Copy, seeking to the next frame reuses the same image
            thumbnail = super().create(frame.copy(), geometry, options)
            thumbnail.info['duration'] = frame.info.get('duration', 0)
            frames.append(thumbnail)
        return frames

    def get_image(self, source):
        buffer = BytesIO(source.read())
        return Image.open(buffer)

    def get_image_size(self, image):
        if isinstance(image, list):  # Animated GIF frames, see create()
            image = image[0]
        return image.size

    def get_image_info(self, image):
        return image.info or {}

    def is_valid_image(self, raw_data):
        buffer = BytesIO(raw_data)
        try:
            # verify() checks the file structure, load() decodes the pixels to catch truncated files
            with Image.open(buffer) as trial_image:
                trial_image.verify()
            buffer.seek(0)
            with Image.open(buffer) as trial_image:
                trial_image.load()
        except Exception:
            return False
        return True

    def colorspace(self, image, geometry, options):
        """
        Wrapper for ``_colorspace``
        """
        colorspace = options['colorspace']
        format = options['format']

        flatten = settings.THUMBNAIL_FLATTEN and options.get('flatten') not in ('off', False)
        transparent = image.mode in ('RGBA', 'LA') or 'transparency' in image.info
        if flatten and transparent and format == 'JPEG':
            # Composite onto a background before JPEG drops the alpha channel, like convert -flatten
            color = options.get('padding_color') if options.get('padding') else '#ffffff'
            rgba = image if image.mode == 'RGBA' else image.convert('RGBA')
            image = Image.new('RGB', image.size, color)
            image.paste(rgba, mask=rgba)

        return self._colorspace(image, colorspace, format)

    def _cropbox(self, image, x, y, x2, y2):
        return image.crop((x, y, x2, y2))

    def _get_exif_orientation(self, image):
        try:
            exif = image._getexif()
        except Exception:
            exif = None

        if exif:
            return exif.get(EXIF_ORIENTATION)
        else:
            return None

    def _orientation(self, image):
        orientation = self._get_exif_orientation(image)

        if orientation:
            if orientation == 2:
                image = image.transpose(FLIP_LEFT_RIGHT)
            elif orientation == 3:
                image = image.rotate(180)
            elif orientation == 4:
                image = image.transpose(FLIP_TOP_BOTTOM)
            elif orientation == 5:
                image = image.rotate(-90, expand=1).transpose(FLIP_LEFT_RIGHT)
            elif orientation == 6:
                image = image.rotate(-90, expand=1)
            elif orientation == 7:
                image = image.rotate(90, expand=1).transpose(FLIP_LEFT_RIGHT)
            elif orientation == 8:
                image = image.rotate(90, expand=1)

        return image

    def _flip_dimensions(self, image):
        orientation = self._get_exif_orientation(image)
        return orientation and orientation in [5, 6, 7, 8]

    def _colorspace(self, image, colorspace, format):
        if colorspace == 'RGB':
            # Pillow JPEG doesn't allow RGBA anymore. It was converted to RGB before.
            if image.mode == 'RGBA' and format != 'JPEG':
                return image  # RGBA is just RGB + Alpha
            if format != 'JPEG' and (
                image.mode == 'LA' or (image.mode == 'P' and 'transparency' in image.info)
            ):
                newimage = image.convert('RGBA')
                transparency = image.info.get('transparency')
                if transparency is not None:
                    mask = image.convert('RGBA').split()[-1]
                    newimage.putalpha(mask)
                return newimage
            return image.convert('RGB')
        if colorspace == 'GRAY':
            return image.convert('L')
        return image

    def _remove_border(self, image, image_width, image_height):
        def entropy(box):
            section = image.crop(box)
            if section.mode not in ('RGBA', 'LA'):
                return self._get_image_entropy(section)
            # A border is plain on black and on white, whatever color is under transparent pixels
            values = []
            for color in ('black', 'white'):
                background = Image.new(section.mode[:-1], section.size, color)
                background.paste(section, mask=section)
                values.append(self._get_image_entropy(background))
            return max(values)

        left, top, right, bottom = 0, 0, image_width, image_height
        # Don't remove too much, the image may just be plain
        max_x, max_y = int(image_width / 3.5), int(image_height / 3.5)

        # Trim plain strips 10px at a time, then 1px at a time to find where the picture starts
        for step in (10, 1):
            while top + step <= max_y and entropy((left, top, right, top + step)) < 2.0:
                top += step
        for step in (10, 1):
            while (bottom - step >= image_height - max_y
                   and entropy((left, bottom - step, right, bottom)) < 2.0):
                bottom -= step
        for step in (10, 1):
            while left + step <= max_x and entropy((left, top, left + step, bottom)) < 2.0:
                left += step
        for step in (10, 1):
            while (right - step >= image_width - max_x
                   and entropy((right - step, top, right, bottom)) < 2.0):
                right -= step

        return image.crop((left, top, right, bottom))

    # Credit to chrisopherhan https://github.com/christopherhan/pycrop
    # This is just a slight rework of pycrops implimentation
    def _entropy_crop(self, image, geometry_width, geometry_height, image_width, image_height):
        geometry_ratio = geometry_width / geometry_height
        target_width = max(min(image_width, round(image_height * geometry_ratio)), 1)
        target_height = max(min(image_height, round(image_width / geometry_ratio)), 1)
        left, top, right, bottom = 0, 0, image_width, image_height

        # Trim the side with less entropy, up to 10px per round, then crop once
        while right - left > target_width:
            step = min(right - left - target_width, 10)
            left_strip = image.crop((left, top, left + step, bottom))
            right_strip = image.crop((right - step, top, right, bottom))
            if self._get_image_entropy(left_strip) < self._get_image_entropy(right_strip):
                left += step
            else:
                right -= step

        while bottom - top > target_height:
            step = min(bottom - top - target_height, 10)
            top_strip = image.crop((left, top, right, top + step))
            bottom_strip = image.crop((left, bottom - step, right, bottom))
            if self._get_image_entropy(bottom_strip) < self._get_image_entropy(top_strip):
                bottom -= step
            else:
                top += step

        return image.crop((left, top, right, bottom))

    # Add the histogram_entropy fumnction as a static method:
    _get_image_entropy = staticmethod(histogram_entropy)

    def _scale(self, image, width, height):
        return image.resize((width, height), resample=ANTIALIAS)

    def _crop(self, image, width, height, x_offset, y_offset):
        return image.crop((x_offset, y_offset,
                           width + x_offset, height + y_offset))

    def _rounded(self, image, r):
        i = round_rectangle(image.size, r, "notusedblack")
        image.putalpha(i)
        return image

    def _blur(self, image, radius):
        if image.mode in ('RGBA', 'LA'):
            # Premultiplied, so the color under transparent pixels doesn't darken the edges
            premultiplied = image.mode[:-1] + 'a'
            return image.convert(premultiplied).filter(GaussianBlur(radius)).convert(image.mode)
        return image.filter(GaussianBlur(radius))

    def _padding(self, image, geometry, options):
        x_image, y_image = self.get_image_size(image)
        left = int((geometry[0] - x_image) / 2)
        top = int((geometry[1] - y_image) / 2)
        color = options.get('padding_color')
        im = Image.new(image.mode, geometry, color)
        im.paste(image, (left, top))
        return im

    def write(self, image, options, thumbnail):
        if options['format'] == 'JPEG' and image.mode in ('RGBA', 'LA'):
            # rounded adds alpha after colorspace, so composite it like flatten
            color = options.get('padding_color') if options.get('padding') else '#ffffff'
            background = Image.new(image.mode[:-1], image.size, color)
            background.paste(image, mask=image)
            image = background

        super().write(image, options, thumbnail)

    def _get_raw_data(self, image, format_, quality, image_info=None, progressive=False):
        frames = image if isinstance(image, list) else [image]  # see create()
        image = frames[0]

        # Increase (but never decrease) PIL buffer size
        ImageFile.MAXBLOCK = max(ImageFile.MAXBLOCK, image.size[0] * image.size[1])
        bf = BytesIO()

        params = {
            'format': format_,
            'quality': quality,
            'optimize': 1,
        }

        if len(frames) > 1:
            params['save_all'] = True
            params['append_images'] = frames[1:]
            params['duration'] = [frame.info['duration'] for frame in frames]
            # Clear each frame before drawing the next one, otherwise
            # transparent animations leave trails
            params['disposal'] = 2

            if 'loop' in image_info:
                params['loop'] = image_info['loop']

        # keeps icc_profile
        if 'icc_profile' in image_info:
            params['icc_profile'] = image_info['icc_profile']

        raw_data = None

        if format_ == 'JPEG' and progressive:
            params['progressive'] = True
        try:
            # Do not save unnecessary exif data for smaller thumbnail size
            params.pop('exif', {})
            image.save(bf, **params)
        except OSError:
            # Try without optimization.
            params.pop('optimize')
            image.save(bf, **params)
        else:
            raw_data = bf.getvalue()
        finally:
            bf.close()

        return raw_data
