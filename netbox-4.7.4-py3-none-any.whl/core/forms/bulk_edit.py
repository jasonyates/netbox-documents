from django import forms
from django.utils.translation import gettext_lazy as _

from core.choices import JobIntervalChoices
from core.models import *
from netbox.forms import PrimaryModelBulkEditForm
from netbox.utils import get_data_backend_choices
from utilities.forms.fields import ChoiceField
from utilities.forms.rendering import FieldSet
from utilities.forms.widgets import BulkEditNullBooleanSelect

__all__ = (
    'DataSourceBulkEditForm',
)


class DataSourceBulkEditForm(PrimaryModelBulkEditForm):
    type = ChoiceField(
        label=_('Type'),
        choices=get_data_backend_choices,
        required=False
    )
    enabled = forms.NullBooleanField(
        required=False,
        widget=BulkEditNullBooleanSelect(),
        label=_('Enabled')
    )
    sync_interval = ChoiceField(
        choices=JobIntervalChoices,
        required=False,
        label=_('Sync interval')
    )
    parameters = forms.JSONField(
        label=_('Parameters'),
        required=False
    )
    ignore_rules = forms.CharField(
        label=_('Ignore rules'),
        required=False,
        widget=forms.Textarea()
    )

    model = DataSource
    fieldsets = (
        FieldSet('type', 'enabled', 'description', 'sync_interval', 'parameters', 'ignore_rules'),
    )
    nullable_fields = (
        'description', 'sync_interval', 'parameters', 'ignore_rules', 'comments',
    )
