import django.core.validators
from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ("extras", "0141_custom_field_nulls_first"),
    ]

    operations = [
        migrations.AddField(
            model_name="webhook",
            name="timeout",
            field=models.PositiveSmallIntegerField(
                blank=True,
                null=True,
                validators=[
                    django.core.validators.MinValueValidator(1),
                    django.core.validators.MaxValueValidator(3600),
                ],
            ),
        ),
    ]
