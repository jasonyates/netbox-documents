from decimal import Decimal

import django.core.validators
import django.db.models.deletion
import taggit.managers
from django.db import migrations, models

import netbox.models.deletion
import utilities.fields
import utilities.json
import utilities.tracking
from utilities.migration import InstallDenormalizationTrigger


class Migration(migrations.Migration):

    dependencies = [
        ("dcim", "0249_interface_channels"),
        ("extras", "0139_alter_customfieldchoiceset_extra_choices"),
        ("tenancy", "0025_ltree_paths"),
        ("users", "0016_default_ordering_indexes"),
    ]

    operations = [
        migrations.AddField(
            model_name="device",
            name="cooling_method",
            field=models.CharField(blank=True, max_length=50, null=True),
        ),
        migrations.AddField(
            model_name="device",
            name="cooling_outflow_count",
            field=utilities.fields.CounterCacheField(
                default=0,
                editable=False,
                to_field="device",
                to_model="dcim.CoolingOutflow",
            ),
        ),
        migrations.AddField(
            model_name="device",
            name="cooling_intake_count",
            field=utilities.fields.CounterCacheField(
                default=0,
                editable=False,
                to_field="device",
                to_model="dcim.CoolingIntake",
            ),
        ),
        migrations.AddField(
            model_name="devicetype",
            name="cooling_method",
            field=models.CharField(blank=True, max_length=50, null=True),
        ),
        migrations.AddField(
            model_name="devicetype",
            name="cooling_outflow_template_count",
            field=utilities.fields.CounterCacheField(
                default=0,
                editable=False,
                to_field="device_type",
                to_model="dcim.CoolingOutflowTemplate",
            ),
        ),
        migrations.AddField(
            model_name="devicetype",
            name="cooling_intake_template_count",
            field=utilities.fields.CounterCacheField(
                default=0,
                editable=False,
                to_field="device_type",
                to_model="dcim.CoolingIntakeTemplate",
            ),
        ),
        migrations.AddField(
            model_name="moduletype",
            name="cooling_method",
            field=models.CharField(blank=True, max_length=50, null=True),
        ),
        migrations.AddField(
            model_name="moduletype",
            name="cooling_outflow_template_count",
            field=utilities.fields.CounterCacheField(
                default=0,
                editable=False,
                to_field="module_type",
                to_model="dcim.CoolingOutflowTemplate",
            ),
        ),
        migrations.AddField(
            model_name="moduletype",
            name="cooling_intake_template_count",
            field=utilities.fields.CounterCacheField(
                default=0,
                editable=False,
                to_field="module_type",
                to_model="dcim.CoolingIntakeTemplate",
            ),
        ),
        migrations.AddField(
            model_name="rack",
            name="cooling_capability",
            field=models.CharField(blank=True, max_length=50, null=True),
        ),
        migrations.AddField(
            model_name="rack",
            name="cooling_capacity",
            field=models.DecimalField(
                blank=True,
                decimal_places=2,
                max_digits=10,
                null=True,
                validators=[django.core.validators.MinValueValidator(0)],
            ),
        ),
        migrations.AddField(
            model_name="racktype",
            name="cooling_capability",
            field=models.CharField(blank=True, max_length=50, null=True),
        ),
        migrations.AddField(
            model_name="racktype",
            name="cooling_capacity",
            field=models.DecimalField(
                blank=True,
                decimal_places=2,
                max_digits=10,
                null=True,
                validators=[django.core.validators.MinValueValidator(0)],
            ),
        ),
        migrations.CreateModel(
            name="CoolingIntake",
            fields=[
                (
                    "id",
                    models.BigAutoField(
                        auto_created=True, primary_key=True, serialize=False
                    ),
                ),
                ("created", models.DateTimeField(auto_now_add=True, null=True)),
                ("last_updated", models.DateTimeField(auto_now=True, null=True)),
                (
                    "custom_field_data",
                    models.JSONField(
                        blank=True,
                        default=dict,
                        encoder=utilities.json.CustomFieldJSONEncoder,
                    ),
                ),
                (
                    "diameter",
                    models.DecimalField(
                        blank=True,
                        decimal_places=2,
                        max_digits=8,
                        null=True,
                        validators=[django.core.validators.MinValueValidator(Decimal('0.01'))],
                    ),
                ),
                (
                    "diameter_unit",
                    models.CharField(blank=True, max_length=50, null=True),
                ),
                (
                    "_abs_diameter",
                    models.DecimalField(
                        blank=True, decimal_places=4, max_digits=13, null=True
                    ),
                ),
                (
                    "max_flow",
                    models.DecimalField(
                        blank=True,
                        decimal_places=2,
                        max_digits=8,
                        null=True,
                        validators=[django.core.validators.MinValueValidator(Decimal('0.01'))],
                    ),
                ),
                (
                    "max_flow_unit",
                    models.CharField(blank=True, max_length=50, null=True),
                ),
                (
                    "_abs_max_flow",
                    models.DecimalField(
                        blank=True, decimal_places=4, max_digits=13, null=True
                    ),
                ),
                ("name", models.CharField(db_collation="natural_sort", max_length=64)),
                ("label", models.CharField(blank=True, max_length=64)),
                ("description", models.CharField(blank=True, max_length=200)),
                ("type", models.CharField(blank=True, max_length=50, null=True)),
                (
                    "_location",
                    models.ForeignKey(
                        blank=True,
                        null=True,
                        on_delete=django.db.models.deletion.SET_NULL,
                        related_name="+",
                        to="dcim.location",
                    ),
                ),
                (
                    "_rack",
                    models.ForeignKey(
                        blank=True,
                        null=True,
                        on_delete=django.db.models.deletion.SET_NULL,
                        related_name="+",
                        to="dcim.rack",
                    ),
                ),
                (
                    "_site",
                    models.ForeignKey(
                        blank=True,
                        null=True,
                        on_delete=django.db.models.deletion.SET_NULL,
                        related_name="+",
                        to="dcim.site",
                    ),
                ),
                (
                    "device",
                    models.ForeignKey(
                        on_delete=django.db.models.deletion.CASCADE,
                        related_name="%(class)ss",
                        to="dcim.device",
                    ),
                ),
                (
                    "module",
                    models.ForeignKey(
                        blank=True,
                        null=True,
                        on_delete=django.db.models.deletion.CASCADE,
                        related_name="%(class)ss",
                        to="dcim.module",
                    ),
                ),
                (
                    "owner",
                    models.ForeignKey(
                        blank=True,
                        null=True,
                        on_delete=django.db.models.deletion.PROTECT,
                        related_name="+",
                        to="users.owner",
                    ),
                ),
                (
                    "tags",
                    taggit.managers.TaggableManager(
                        through="extras.TaggedItem", to="extras.Tag"
                    ),
                ),
            ],
            options={
                "verbose_name": "cooling intake",
                "verbose_name_plural": "cooling intakes",
                "ordering": ("device", "name"),
                "abstract": False,
            },
            bases=(
                netbox.models.deletion.DeleteMixin,
                models.Model,
                utilities.tracking.TrackingModelMixin,
            ),
        ),
        migrations.CreateModel(
            name="CoolingOutflow",
            fields=[
                (
                    "id",
                    models.BigAutoField(
                        auto_created=True, primary_key=True, serialize=False
                    ),
                ),
                ("created", models.DateTimeField(auto_now_add=True, null=True)),
                ("last_updated", models.DateTimeField(auto_now=True, null=True)),
                (
                    "custom_field_data",
                    models.JSONField(
                        blank=True,
                        default=dict,
                        encoder=utilities.json.CustomFieldJSONEncoder,
                    ),
                ),
                (
                    "diameter",
                    models.DecimalField(
                        blank=True,
                        decimal_places=2,
                        max_digits=8,
                        null=True,
                        validators=[django.core.validators.MinValueValidator(Decimal('0.01'))],
                    ),
                ),
                (
                    "diameter_unit",
                    models.CharField(blank=True, max_length=50, null=True),
                ),
                (
                    "_abs_diameter",
                    models.DecimalField(
                        blank=True, decimal_places=4, max_digits=13, null=True
                    ),
                ),
                ("name", models.CharField(db_collation="natural_sort", max_length=64)),
                ("label", models.CharField(blank=True, max_length=64)),
                ("description", models.CharField(blank=True, max_length=200)),
                ("type", models.CharField(blank=True, max_length=50, null=True)),
                (
                    "_location",
                    models.ForeignKey(
                        blank=True,
                        null=True,
                        on_delete=django.db.models.deletion.SET_NULL,
                        related_name="+",
                        to="dcim.location",
                    ),
                ),
                (
                    "_rack",
                    models.ForeignKey(
                        blank=True,
                        null=True,
                        on_delete=django.db.models.deletion.SET_NULL,
                        related_name="+",
                        to="dcim.rack",
                    ),
                ),
                (
                    "_site",
                    models.ForeignKey(
                        blank=True,
                        null=True,
                        on_delete=django.db.models.deletion.SET_NULL,
                        related_name="+",
                        to="dcim.site",
                    ),
                ),
                (
                    "device",
                    models.ForeignKey(
                        on_delete=django.db.models.deletion.CASCADE,
                        related_name="%(class)ss",
                        to="dcim.device",
                    ),
                ),
                (
                    "module",
                    models.ForeignKey(
                        blank=True,
                        null=True,
                        on_delete=django.db.models.deletion.CASCADE,
                        related_name="%(class)ss",
                        to="dcim.module",
                    ),
                ),
                (
                    "owner",
                    models.ForeignKey(
                        blank=True,
                        null=True,
                        on_delete=django.db.models.deletion.PROTECT,
                        related_name="+",
                        to="users.owner",
                    ),
                ),
                (
                    "tags",
                    taggit.managers.TaggableManager(
                        through="extras.TaggedItem", to="extras.Tag"
                    ),
                ),
                (
                    "cooling_intake",
                    models.ForeignKey(
                        blank=True,
                        null=True,
                        on_delete=django.db.models.deletion.SET_NULL,
                        related_name="coolingoutflows",
                        to="dcim.coolingintake",
                    ),
                ),
            ],
            options={
                "verbose_name": "cooling outflow",
                "verbose_name_plural": "cooling outflows",
                "ordering": ("device", "name"),
                "abstract": False,
            },
            bases=(
                netbox.models.deletion.DeleteMixin,
                models.Model,
                utilities.tracking.TrackingModelMixin,
            ),
        ),
        migrations.CreateModel(
            name="CoolingIntakeTemplate",
            fields=[
                (
                    "id",
                    models.BigAutoField(
                        auto_created=True, primary_key=True, serialize=False
                    ),
                ),
                ("created", models.DateTimeField(auto_now_add=True, null=True)),
                ("last_updated", models.DateTimeField(auto_now=True, null=True)),
                (
                    "diameter",
                    models.DecimalField(
                        blank=True,
                        decimal_places=2,
                        max_digits=8,
                        null=True,
                        validators=[django.core.validators.MinValueValidator(Decimal('0.01'))],
                    ),
                ),
                (
                    "diameter_unit",
                    models.CharField(blank=True, max_length=50, null=True),
                ),
                (
                    "_abs_diameter",
                    models.DecimalField(
                        blank=True, decimal_places=4, max_digits=13, null=True
                    ),
                ),
                (
                    "max_flow",
                    models.DecimalField(
                        blank=True,
                        decimal_places=2,
                        max_digits=8,
                        null=True,
                        validators=[django.core.validators.MinValueValidator(Decimal('0.01'))],
                    ),
                ),
                (
                    "max_flow_unit",
                    models.CharField(blank=True, max_length=50, null=True),
                ),
                (
                    "_abs_max_flow",
                    models.DecimalField(
                        blank=True, decimal_places=4, max_digits=13, null=True
                    ),
                ),
                ("name", models.CharField(db_collation="natural_sort", max_length=64)),
                ("label", models.CharField(blank=True, max_length=64)),
                ("description", models.CharField(blank=True, max_length=200)),
                ("type", models.CharField(blank=True, max_length=50, null=True)),
                (
                    "device_type",
                    models.ForeignKey(
                        blank=True,
                        null=True,
                        on_delete=django.db.models.deletion.CASCADE,
                        related_name="%(class)ss",
                        to="dcim.devicetype",
                    ),
                ),
                (
                    "module_type",
                    models.ForeignKey(
                        blank=True,
                        null=True,
                        on_delete=django.db.models.deletion.CASCADE,
                        related_name="%(class)ss",
                        to="dcim.moduletype",
                    ),
                ),
            ],
            options={
                "verbose_name": "cooling intake template",
                "verbose_name_plural": "cooling intake templates",
                "ordering": ("device_type", "module_type", "name"),
                "abstract": False,
            },
            bases=(
                netbox.models.deletion.DeleteMixin,
                models.Model,
                utilities.tracking.TrackingModelMixin,
            ),
        ),
        migrations.CreateModel(
            name="CoolingOutflowTemplate",
            fields=[
                (
                    "id",
                    models.BigAutoField(
                        auto_created=True, primary_key=True, serialize=False
                    ),
                ),
                ("created", models.DateTimeField(auto_now_add=True, null=True)),
                ("last_updated", models.DateTimeField(auto_now=True, null=True)),
                (
                    "diameter",
                    models.DecimalField(
                        blank=True,
                        decimal_places=2,
                        max_digits=8,
                        null=True,
                        validators=[django.core.validators.MinValueValidator(Decimal('0.01'))],
                    ),
                ),
                (
                    "diameter_unit",
                    models.CharField(blank=True, max_length=50, null=True),
                ),
                (
                    "_abs_diameter",
                    models.DecimalField(
                        blank=True, decimal_places=4, max_digits=13, null=True
                    ),
                ),
                ("name", models.CharField(db_collation="natural_sort", max_length=64)),
                ("label", models.CharField(blank=True, max_length=64)),
                ("description", models.CharField(blank=True, max_length=200)),
                ("type", models.CharField(blank=True, max_length=50, null=True)),
                (
                    "device_type",
                    models.ForeignKey(
                        blank=True,
                        null=True,
                        on_delete=django.db.models.deletion.CASCADE,
                        related_name="%(class)ss",
                        to="dcim.devicetype",
                    ),
                ),
                (
                    "module_type",
                    models.ForeignKey(
                        blank=True,
                        null=True,
                        on_delete=django.db.models.deletion.CASCADE,
                        related_name="%(class)ss",
                        to="dcim.moduletype",
                    ),
                ),
                (
                    "cooling_intake",
                    models.ForeignKey(
                        blank=True,
                        null=True,
                        on_delete=django.db.models.deletion.SET_NULL,
                        related_name="coolingoutflow_templates",
                        to="dcim.coolingintaketemplate",
                    ),
                ),
            ],
            options={
                "verbose_name": "cooling outflow template",
                "verbose_name_plural": "cooling outflow templates",
                "ordering": ("device_type", "module_type", "name"),
                "abstract": False,
            },
            bases=(
                netbox.models.deletion.DeleteMixin,
                models.Model,
                utilities.tracking.TrackingModelMixin,
            ),
        ),
        migrations.CreateModel(
            name="CoolingSource",
            fields=[
                (
                    "id",
                    models.BigAutoField(
                        auto_created=True, primary_key=True, serialize=False
                    ),
                ),
                ("created", models.DateTimeField(auto_now_add=True, null=True)),
                ("last_updated", models.DateTimeField(auto_now=True, null=True)),
                (
                    "custom_field_data",
                    models.JSONField(
                        blank=True,
                        default=dict,
                        encoder=utilities.json.CustomFieldJSONEncoder,
                    ),
                ),
                ("description", models.CharField(blank=True, max_length=200)),
                ("comments", models.TextField(blank=True)),
                ("name", models.CharField(db_collation="natural_sort", max_length=100)),
                ("type", models.CharField(max_length=50)),
                ("status", models.CharField(default="active", max_length=50)),
                ("fluid_type", models.CharField(blank=True, max_length=50, null=True)),
                (
                    "cooling_capacity",
                    models.DecimalField(
                        blank=True,
                        decimal_places=2,
                        max_digits=10,
                        null=True,
                        validators=[django.core.validators.MinValueValidator(0)],
                    ),
                ),
                (
                    "location",
                    models.ForeignKey(
                        blank=True,
                        null=True,
                        on_delete=django.db.models.deletion.PROTECT,
                        to="dcim.location",
                    ),
                ),
                (
                    "owner",
                    models.ForeignKey(
                        blank=True,
                        null=True,
                        on_delete=django.db.models.deletion.PROTECT,
                        related_name="+",
                        to="users.owner",
                    ),
                ),
                (
                    "site",
                    models.ForeignKey(
                        on_delete=django.db.models.deletion.PROTECT, to="dcim.site"
                    ),
                ),
                (
                    "tags",
                    taggit.managers.TaggableManager(
                        through="extras.TaggedItem", to="extras.Tag"
                    ),
                ),
            ],
            options={
                "verbose_name": "cooling source",
                "verbose_name_plural": "cooling sources",
                "ordering": ["site", "name"],
            },
            bases=(netbox.models.deletion.DeleteMixin, models.Model),
        ),
        migrations.CreateModel(
            name="CoolingFeed",
            fields=[
                (
                    "id",
                    models.BigAutoField(
                        auto_created=True, primary_key=True, serialize=False
                    ),
                ),
                ("created", models.DateTimeField(auto_now_add=True, null=True)),
                ("last_updated", models.DateTimeField(auto_now=True, null=True)),
                (
                    "custom_field_data",
                    models.JSONField(
                        blank=True,
                        default=dict,
                        encoder=utilities.json.CustomFieldJSONEncoder,
                    ),
                ),
                (
                    "max_flow",
                    models.DecimalField(
                        blank=True,
                        decimal_places=2,
                        max_digits=8,
                        null=True,
                        validators=[django.core.validators.MinValueValidator(Decimal('0.01'))],
                    ),
                ),
                (
                    "max_flow_unit",
                    models.CharField(blank=True, max_length=50, null=True),
                ),
                (
                    "_abs_max_flow",
                    models.DecimalField(
                        blank=True, decimal_places=4, max_digits=13, null=True
                    ),
                ),
                ("description", models.CharField(blank=True, max_length=200)),
                ("comments", models.TextField(blank=True)),
                ("name", models.CharField(db_collation="natural_sort", max_length=100)),
                ("status", models.CharField(default="active", max_length=50)),
                (
                    "cooling_capacity",
                    models.DecimalField(
                        blank=True,
                        decimal_places=2,
                        max_digits=10,
                        null=True,
                        validators=[django.core.validators.MinValueValidator(0)],
                    ),
                ),
                (
                    "owner",
                    models.ForeignKey(
                        blank=True,
                        null=True,
                        on_delete=django.db.models.deletion.PROTECT,
                        related_name="+",
                        to="users.owner",
                    ),
                ),
                (
                    "rack",
                    models.ForeignKey(
                        blank=True,
                        null=True,
                        on_delete=django.db.models.deletion.PROTECT,
                        related_name="cooling_feeds",
                        to="dcim.rack",
                    ),
                ),
                (
                    "tags",
                    taggit.managers.TaggableManager(
                        through="extras.TaggedItem", to="extras.Tag"
                    ),
                ),
                (
                    "tenant",
                    models.ForeignKey(
                        blank=True,
                        null=True,
                        on_delete=django.db.models.deletion.PROTECT,
                        related_name="cooling_feeds",
                        to="tenancy.tenant",
                    ),
                ),
                (
                    "cooling_source",
                    models.ForeignKey(
                        on_delete=django.db.models.deletion.PROTECT,
                        related_name="cooling_feeds",
                        to="dcim.coolingsource",
                    ),
                ),
            ],
            options={
                "verbose_name": "cooling feed",
                "verbose_name_plural": "cooling feeds",
                "ordering": ["cooling_source", "name"],
            },
            bases=(netbox.models.deletion.DeleteMixin, models.Model),
        ),
        migrations.AddField(
            model_name="coolingintake",
            name="cooling_outflow",
            field=models.ForeignKey(
                blank=True,
                null=True,
                on_delete=django.db.models.deletion.SET_NULL,
                related_name="coolingintakes",
                to="dcim.coolingoutflow",
            ),
        ),
        migrations.AddConstraint(
            model_name="coolingintake",
            constraint=models.UniqueConstraint(
                fields=("device", "name"), name="dcim_coolingintake_unique_device_name"
            ),
        ),
        migrations.AddConstraint(
            model_name="coolingoutflow",
            constraint=models.UniqueConstraint(
                fields=("device", "name"), name="dcim_coolingoutflow_unique_device_name"
            ),
        ),
        migrations.AddIndex(
            model_name="coolingintaketemplate",
            index=models.Index(
                fields=["device_type", "module_type", "name"],
                name="dcim_coolin_device__ee88f9_idx",
            ),
        ),
        migrations.AddConstraint(
            model_name="coolingintaketemplate",
            constraint=models.UniqueConstraint(
                fields=("device_type", "name"),
                name="dcim_coolingintaketemplate_unique_device_type_name",
            ),
        ),
        migrations.AddConstraint(
            model_name="coolingintaketemplate",
            constraint=models.UniqueConstraint(
                fields=("module_type", "name"),
                name="dcim_coolingintaketemplate_unique_module_type_name",
            ),
        ),
        migrations.AddIndex(
            model_name="coolingoutflowtemplate",
            index=models.Index(
                fields=["device_type", "module_type", "name"],
                name="dcim_coolin_device__4d0859_idx",
            ),
        ),
        migrations.AddConstraint(
            model_name="coolingoutflowtemplate",
            constraint=models.UniqueConstraint(
                fields=("device_type", "name"),
                name="dcim_coolingoutflowtemplate_unique_device_type_name",
            ),
        ),
        migrations.AddConstraint(
            model_name="coolingoutflowtemplate",
            constraint=models.UniqueConstraint(
                fields=("module_type", "name"),
                name="dcim_coolingoutflowtemplate_unique_module_type_name",
            ),
        ),
        migrations.AddConstraint(
            model_name="coolingsource",
            constraint=models.UniqueConstraint(
                fields=("site", "name"), name="dcim_coolingsource_unique_site_name"
            ),
        ),
        migrations.AddConstraint(
            model_name="coolingfeed",
            constraint=models.UniqueConstraint(
                fields=("cooling_source", "name"),
                name="dcim_coolingfeed_unique_cooling_source_name",
            ),
        ),
        # Install denormalized device → component triggers for the cooling device components,
        # mirroring the triggers created for the other device components in migration 0243.
        *[
            InstallDenormalizationTrigger(
                dependent_table=table,
                source_table="dcim_device",
                fk_column="device_id",
                mappings={"_site_id": "site_id", "_location_id": "location_id", "_rack_id": "rack_id"},
            )
            for table in ("dcim_coolingintake", "dcim_coolingoutflow")
        ],
    ]
