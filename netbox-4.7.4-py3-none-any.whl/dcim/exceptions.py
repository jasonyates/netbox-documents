class UnsupportedCablePath(Exception):
    pass
