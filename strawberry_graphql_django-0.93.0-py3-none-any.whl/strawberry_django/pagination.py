import sys
import warnings
from typing import Generic, TypeVar, cast

import strawberry
from django.db import DEFAULT_DB_ALIAS
from django.db.models import Count, QuerySet, Window
from django.db.models.functions import RowNumber
from django.db.models.query import MAX_GET_RESULTS  # type: ignore
from strawberry.types import Info
from strawberry.types.arguments import StrawberryArgument
from strawberry.types.unset import UNSET, UnsetType
from typing_extensions import Self

from strawberry_django.fields.base import StrawberryDjangoFieldBase
from strawberry_django.resolvers import django_resolver

from .arguments import argument
from .settings import strawberry_django_settings

NodeType = TypeVar("NodeType")
_QS = TypeVar("_QS", bound=QuerySet)

PAGINATION_ARG = "pagination"


def _resolve_limit(
    limit: int | UnsetType | None,
    *,
    max_results: int | None = None,
) -> int | None:
    """Calculate the effective limit to apply.

    Args:
    ----
        limit: The requested limit (can be UNSET, None, or an explicit value).
        max_results: Override for default limit (used by relay pagination).

    Returns:
    -------
        The effective limit to apply, or None for unlimited.

    """
    settings = strawberry_django_settings()
    default_limit = (
        max_results if max_results is not None else settings["PAGINATION_DEFAULT_LIMIT"]
    )
    max_limit = settings["PAGINATION_MAX_LIMIT"]

    effective_limit: int | None
    if limit is UNSET or limit is None:
        effective_limit = default_limit
    else:
        effective_limit = cast("int", limit)

    if max_limit is not None:
        if max_limit < 0:
            raise ValueError(
                f"PAGINATION_MAX_LIMIT must be non-negative, got {max_limit}"
            )
        if (
            effective_limit is None
            or effective_limit < 0
            or effective_limit > max_limit
        ):
            effective_limit = max_limit

    return effective_limit


@strawberry.type
class OffsetPaginationInfo:
    offset: int = 0
    limit: int | None = UNSET


@strawberry.input
class OffsetPaginationInput(OffsetPaginationInfo): ...


@strawberry.type
class OffsetPaginated(Generic[NodeType]):
    queryset: strawberry.Private[QuerySet | None]
    pagination: strawberry.Private[OffsetPaginationInput]

    @strawberry.field
    def page_info(self) -> OffsetPaginationInfo:
        return OffsetPaginationInfo(
            limit=_resolve_limit(self.pagination.limit),
            offset=self.pagination.offset,
        )

    @strawberry.field(description="Total count of existing results.")
    @django_resolver
    def total_count(self) -> int:
        return self.get_total_count()

    @strawberry.field(description="List of paginated results.")
    @django_resolver
    def results(self) -> list[NodeType]:
        paginated_queryset = self.get_paginated_queryset()

        return cast(
            "list[NodeType]",
            paginated_queryset if paginated_queryset is not None else [],
        )

    @classmethod
    def resolve_paginated(
        cls,
        queryset: QuerySet,
        *,
        info: Info,
        pagination: OffsetPaginationInput | None = None,
        **kwargs,
    ) -> Self:
        """Resolve the paginated queryset.

        Args:
            queryset: The queryset to be paginated.
            info: The strawberry execution info resolve the type name from.
            pagination: The pagination input to be applied.
            kwargs: Additional arguments passed to the resolver.

        Returns:
            The resolved `OffsetPaginated`

        """
        return cls(
            queryset=queryset,
            pagination=pagination or OffsetPaginationInput(),
        )

    def get_total_count(self) -> int:
        """Retrieve tht total count of the queryset without pagination."""
        return get_total_count(self.queryset) if self.queryset is not None else 0

    def get_paginated_queryset(self) -> QuerySet | None:
        """Retrieve the queryset with pagination applied.

        This will apply the paginated arguments to the queryset and return it.
        To use the original queryset, access `.queryset` directly.
        """
        from strawberry_django.optimizer import is_optimized_by_prefetching

        if self.queryset is None:
            return None

        return (
            self.queryset._result_cache  # type: ignore
            if is_optimized_by_prefetching(self.queryset)
            else apply(self.pagination, self.queryset)
        )


def apply(
    pagination: object | None,
    queryset: _QS,
    *,
    related_field_id: str | None = None,
) -> _QS:
    """Apply pagination to a queryset.

    Args:
    ----
        pagination: The pagination input.
        queryset: The queryset to apply pagination to.
        related_field_id: The related field id to apply pagination to.
          When provided, the pagination will be applied using window functions
          instead of slicing the queryset.
          Useful for prefetches, as those cannot be sliced after being filtered

    """
    if pagination in (None, strawberry.UNSET):  # ruff: ignore[literal-membership]
        return queryset

    if not isinstance(pagination, OffsetPaginationInput):
        raise TypeError(f"Don't know how to resolve pagination {pagination!r}")

    if related_field_id is not None:
        queryset = apply_window_pagination(
            queryset,
            related_field_id=related_field_id,
            offset=pagination.offset,
            limit=pagination.limit,
        )
    else:
        start = pagination.offset
        limit = _resolve_limit(pagination.limit)

        if limit is not None and limit >= 0:
            stop = start + limit
            queryset = queryset[start:stop]
        else:
            queryset = queryset[start:]

    return queryset


class _PaginationWindow(Window):
    """Window function to be used for pagination.

    This is the same as django's `Window` function, but we can easily identify
    it in case we need to remove it from the queryset, as there might be other
    window functions in the queryset and no other way to identify ours.
    """


def apply_window_pagination(
    queryset: _QS,
    *,
    related_field_id: str,
    offset: int = 0,
    limit: int | None = UNSET,
    max_results: int | None = None,
    reverse: bool = False,
) -> _QS:
    """Apply pagination using window functions.

    Useful for prefetches, as those cannot be sliced after being filtered.

    This is based on the same solution that Django uses, which was implemented
    in https://github.com/django/django/pull/15957

    Args:
    ----
        queryset: The queryset to apply pagination to.
        related_field_id: The related field id to apply pagination to.
        offset: The offset to start the pagination from.
        limit: The limit of items to return.
        reverse: The need to reverse queryset ordering for backwards relay pagination

    """
    limit = _resolve_limit(limit, max_results=max_results)

    order_by = [
        expr
        for expr, _ in queryset.query.get_compiler(
            using=queryset._db or DEFAULT_DB_ALIAS  # type: ignore
        ).get_order_by()
    ]

    queryset = queryset.annotate(
        _strawberry_row_number=_PaginationWindow(
            RowNumber(),
            partition_by=related_field_id,
            order_by=order_by,
        ),
        _strawberry_total_count=_PaginationWindow(
            Count(1),
            partition_by=related_field_id,
        ),
    )

    if offset:
        queryset = queryset.filter(_strawberry_row_number__gt=offset)

    if reverse:
        order_by_reverse = [
            expr
            for expr, _ in queryset
            .reverse()
            .query.get_compiler(
                using=queryset._db or DEFAULT_DB_ALIAS  # type: ignore
            )
            .get_order_by()
        ]
        queryset = queryset.annotate(
            _strawberry_row_number_reversed=_PaginationWindow(
                RowNumber(),
                partition_by=related_field_id,
                order_by=order_by_reverse,
            ),
        )
        return queryset.filter(_strawberry_row_number_reversed__lte=limit)

    # Limit == -1 means no limit. sys.maxsize is set by relay when paginating
    # from the end to as a way to mimic a "not limit" as well
    if limit is not None and limit >= 0 and limit != sys.maxsize:
        queryset = queryset.filter(_strawberry_row_number__lte=offset + limit)

    return queryset


def remove_window_pagination(queryset: _QS) -> _QS:
    """Remove pagination window functions from a queryset.

    Utility function to remove the pagination `WHERE` clause and annotations
    added by the `apply_window_pagination` function.

    Args:
    ----
        queryset: The queryset to apply pagination to.

    """
    queryset = queryset._chain()  # type: ignore
    queryset.query.where.children = [
        child
        for child in queryset.query.where.children
        if (not hasattr(child, "lhs") or not isinstance(child.lhs, _PaginationWindow))
    ]
    queryset.query.annotations = {  # type: ignore
        key: value
        for key, value in queryset.query.annotations.items()
        if not isinstance(value, _PaginationWindow)
    }
    return queryset


def get_total_count(queryset: QuerySet) -> int:
    """Get the total count of a queryset.

    Try to get the total count from the queryset cache, if it's optimized by
    prefetching. Otherwise, fallback to the `QuerySet.count()` method.
    """
    from strawberry_django.optimizer import is_optimized_by_prefetching

    total_count = get_cached_total_count(queryset)
    if total_count is not None:
        return total_count

    if is_optimized_by_prefetching(queryset):
        if queryset._result_cache == [] and _is_non_empty_first_page_window(  # type: ignore
            queryset
        ):
            # An empty first page (no offset, limit >= 1) can only come from an
            # empty partition, so there is nothing to count. This avoids one
            # COUNT query per parent without results in nested connections.
            return 0

        # If we have no results, we can't get the total count from the cache.
        # In this case we will remove the pagination filter to be able to `.count()`
        # the whole queryset with its original filters.
        queryset = remove_window_pagination(queryset)

    return queryset.count()


def get_cached_total_count(queryset: QuerySet) -> int | None:
    """Get the total count from the prefetched window annotation, without running any query.

    Returns None when the count cannot be determined without hitting the
    database; callers should then fall back to `get_total_count`, deferring
    it to a thread when running in an async context.
    """
    from strawberry_django.optimizer import is_optimized_by_prefetching

    if not is_optimized_by_prefetching(queryset):
        return None

    # `_result_cache` is either None or the fully evaluated row list (Django
    # populates it atomically in `_fetch_all`), so a truthy cache means every
    # row of the windowed prefetch query is in memory. All rows carry the same
    # window annotations, so the first row is representative; the
    # AttributeError fallback below covers rows that lack them.
    results = queryset._result_cache  # type: ignore
    if not results:
        return None

    # If the queryset has DISTINCT enabled, the _strawberry_total_count
    # annotation won't be accurate because window functions are evaluated
    # before DISTINCT in SQL. Fall back to queryset.count() instead.
    if queryset.query.distinct:
        return None

    try:
        return results[0]._strawberry_total_count
    except AttributeError:
        warnings.warn(
            (
                "Pagination annotations not found, falling back to QuerySet resolution. "
                "This might cause n+1 issues..."
            ),
            RuntimeWarning,
            stacklevel=3,
        )
        return None


def _is_non_empty_first_page_window(queryset: QuerySet) -> bool:
    """Whether the window pagination on ``queryset`` selects a first page that can hold at least one row.

    `apply_window_pagination` expresses pagination exclusively as `gt` (offset)
    and `lte` (offset + limit) filters against its `_PaginationWindow` row
    numbers. Those row numbers are computed over the queryset with all of its
    other filters already applied, so a page with no offset and room for at
    least one row (every `lte` bound is >= 1) coming back empty proves that
    `remove_window_pagination(queryset).count()` would return 0.

    Any other filter shape on a `_PaginationWindow` is not produced by
    `apply_window_pagination`; be conservative and report False for it so
    callers fall back to counting.

    Note that no window *filters* at all is a valid first-page shape: an
    offset of 0 with no limit fetches whole partitions, filterless. What must
    be present are the `_PaginationWindow` *annotations*, proving the queryset
    went through `apply_window_pagination` in the first place.
    """
    if not any(
        isinstance(annotation, _PaginationWindow)
        for annotation in queryset.query.annotations.values()
    ):
        return False

    for child in queryset.query.where.children:
        if not isinstance(getattr(child, "lhs", None), _PaginationWindow):
            continue

        if getattr(child, "lookup_name", None) != "lte":
            # A `gt` filter means an offset was applied: an empty page past
            # the end says nothing about the partition size. Anything else is
            # an unrecognized shape we can't reason about.
            return False

        rhs = getattr(child, "rhs", None)
        if not isinstance(rhs, int) or rhs < 1:
            # A zero-sized page (limit 0) is empty even for non-empty
            # partitions; a missing or non-integer bound is an unrecognized
            # shape we can't reason about.
            return False

    return True


class StrawberryDjangoPagination(StrawberryDjangoFieldBase):
    def __init__(self, pagination: bool | UnsetType = UNSET, **kwargs):
        self.pagination = pagination
        super().__init__(**kwargs)

    def __copy__(self) -> Self:
        new_field = super().__copy__()
        new_field.pagination = self.pagination
        return new_field

    def _has_pagination(self) -> bool:
        if isinstance(self.pagination, bool):
            return self.pagination

        if self.is_paginated:
            return True

        django_type = self.django_type
        if django_type is not None and not issubclass(
            django_type, strawberry.relay.Node
        ):
            return django_type.__strawberry_django_definition__.pagination

        return False

    @property
    def arguments(self) -> list[StrawberryArgument]:
        arguments = []
        if (
            self.base_resolver is None
            and (self.is_list or self.is_paginated)
            and not self.is_model_property
        ):
            pagination = self.get_pagination()
            if pagination is not None:
                arguments.append(
                    argument("pagination", OffsetPaginationInput, is_optional=True),
                )
        return super().arguments + arguments

    @arguments.setter
    def arguments(self, value: list[StrawberryArgument]):
        args_prop = super(StrawberryDjangoPagination, self.__class__).arguments
        return args_prop.fset(self, value)  # type: ignore

    def get_pagination(self) -> type | None:
        return OffsetPaginationInput if self._has_pagination() else None

    def apply_pagination(
        self,
        queryset: _QS,
        pagination: object | None = None,
        *,
        related_field_id: str | None = None,
    ) -> _QS:
        return apply(pagination, queryset, related_field_id=related_field_id)

    def get_queryset(
        self,
        queryset: _QS,
        info: Info,
        *,
        pagination: OffsetPaginationInput | None = None,
        _strawberry_related_field_id: str | None = None,
        **kwargs,
    ) -> _QS:
        queryset = super().get_queryset(queryset, info, **kwargs)

        # If the queryset is not ordered, and this field is either going to return
        # multiple records, or call `.first()`, then order by the primary key to ensure
        # deterministic results.
        # Skip this for already evaluated querysets (e.g. from a `prefetch_related`
        # hint), since ordering them would discard their results and query again.
        if (
            not queryset.ordered
            and queryset._result_cache is None  # type: ignore
            and (
                self.is_list
                or self.is_paginated
                or self.is_connection
                or self.is_optional
            )
        ):
            queryset = queryset.order_by("pk")

        # This is counter intuitive, but in case we are returning a `Paginated`
        # result, we want to set the original queryset _as is_ as it will apply
        # the pagination later on when resolving its `.results` field.
        # Check `get_wrapped_result` below for more details.
        if self.is_paginated:
            return queryset

        # Add implicit pagination if this field is not a list
        # that way when first() / get() is called on the QuerySet it does not cause extra queries
        # and we don't prefetch more than necessary
        if (
            not pagination
            and not (self.is_list or self.is_paginated or self.is_connection)
            and not _strawberry_related_field_id
        ):
            if self.is_optional:
                pagination = OffsetPaginationInput(offset=0, limit=1)
            else:
                pagination = OffsetPaginationInput(offset=0, limit=MAX_GET_RESULTS)

        return self.apply_pagination(
            queryset,
            pagination,
            related_field_id=_strawberry_related_field_id,
        )
