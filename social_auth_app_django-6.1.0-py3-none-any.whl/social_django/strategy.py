from __future__ import annotations

from importlib import import_module
from typing import TYPE_CHECKING, Any

from django.conf import settings
from django.contrib.auth import authenticate, get_user
from django.contrib.contenttypes.models import ContentType
from django.db.models import Model
from django.http import HttpRequest, HttpResponse
from django.shortcuts import redirect, render, resolve_url
from django.template import TemplateDoesNotExist, engines, loader
from django.utils.crypto import get_random_string
from django.utils.datastructures import MultiValueDict
from django.utils.encoding import force_str
from django.utils.functional import Promise
from django.utils.translation import get_language
from social_core.strategy import BaseStrategy, BaseTemplateStrategy
from social_core.utils import PARTIAL_TOKEN_PENDING_CONFIRMATION_SESSION_NAME

if TYPE_CHECKING:
    from django.contrib.sessions.backends.base import SessionBase
    from social_core.backends.base import BaseAuth
    from social_core.storage import PartialMixin


PARTIAL_PIPELINE_CONFIRMATION_NONCE_PARAMETER = "partial_pipeline_confirm_nonce"


def render_template_string(request, html, context=None):
    """
    Take a template in the form of a string and render it for the
    given context
    """
    template = engines["django"].from_string(html)
    return template.render(context=context, request=request)


class DjangoTemplateStrategy(BaseTemplateStrategy):
    def render_template(self, tpl, context):
        template = loader.get_template(tpl)
        return template.render(context=context, request=self.strategy.request)

    def render_string(self, html, context):
        return render_template_string(self.strategy.request, html, context)


def create_session(session_key: str | None = None) -> SessionBase:
    engine = import_module(settings.SESSION_ENGINE)
    return engine.SessionStore(session_key)


class DjangoStrategy(BaseStrategy):
    DEFAULT_TEMPLATE_STRATEGY = DjangoTemplateStrategy
    _session: SessionBase

    def __init__(self, storage, request: HttpRequest | None = None, tpl=None):
        self.request = request
        if request:
            self.session = request.session
        super().__init__(storage, tpl)

    def _require_request(self) -> HttpRequest:
        if self.request is None:
            msg = "This strategy operation requires an HTTP request"
            raise RuntimeError(msg)
        return self.request

    @property
    def session(self) -> SessionBase:
        try:
            return self._session
        except AttributeError:
            self._session = create_session()
            return self._session

    @session.setter
    def session(self, value: SessionBase) -> None:
        self._session = value

    def get_setting(self, name):
        value = getattr(settings, name)
        # Force text on URL named settings that are instance of Promise
        if name.endswith("_URL"):
            if isinstance(value, Promise):
                value = force_str(value)
            value = resolve_url(value)
        return value

    def request_data(self, merge=True):
        if not self.request:
            return {}
        if merge:
            data = self.request.GET.copy()
            data.update(self.request.POST)
        elif self.request.method == "POST":
            data = self.request.POST
        else:
            data = self.request.GET
        return data

    def request_host(self):
        if self.request:
            return self.request.get_host()
        return None

    def request_is_secure(self):
        """Is the request using HTTPS?"""
        return self._require_request().is_secure()

    def request_path(self):
        """Path of the current request"""
        return self._require_request().path

    def request_port(self):
        """Port in use for this request"""
        return self._require_request().get_port()

    def request_get(self):
        """Request GET data"""
        return self._require_request().GET.copy()

    def request_post(self):
        """Request POST data"""
        return self._require_request().POST.copy()

    def redirect(self, url):
        return redirect(url)

    def html(self, content):
        return HttpResponse(content, content_type="text/html;charset=UTF-8")

    def partial_pipeline_external_resume_confirmation(  # type: ignore[override]
        self,
        backend: BaseAuth,
        partial: PartialMixin,
        request_data: dict[str, Any],
    ) -> HttpResponse | None:
        if not self.request:
            return None

        nonce = self.random_string(32)
        self.session_set(PARTIAL_TOKEN_PENDING_CONFIRMATION_SESSION_NAME, nonce)
        confirmation_parameter = backend.setting(
            "PARTIAL_PIPELINE_EXTERNAL_RESUME_CONFIRMATION_PARAMETER",
            "partial_pipeline_confirm",
        )
        return render(
            self.request,
            "social_django/partial_pipeline_external_resume.html",
            {
                "action_url": self.request.path,
                "backend": backend,
                "backend_name": backend.name,
                "confirmation_parameter": confirmation_parameter,
                "confirmation_value": "1",
                "confirmation_nonce_parameter": (PARTIAL_PIPELINE_CONFIRMATION_NONCE_PARAMETER),
                "confirmation_nonce": nonce,
                "partial": partial,
            },
        )

    def partial_pipeline_external_resume_confirmed(
        self,
        backend: BaseAuth,
        request_data: dict[str, Any],
    ) -> bool:
        if not self.request or self.request.method != "POST":
            return False

        confirmation_parameter = backend.setting(
            "PARTIAL_PIPELINE_EXTERNAL_RESUME_CONFIRMATION_PARAMETER",
            "partial_pipeline_confirm",
        )
        if not confirmation_parameter or confirmation_parameter not in request_data:
            return False

        expected_nonce = self.session_get(PARTIAL_TOKEN_PENDING_CONFIRMATION_SESSION_NAME)
        submitted_nonce = request_data.get(PARTIAL_PIPELINE_CONFIRMATION_NONCE_PARAMETER)
        return bool(expected_nonce) and submitted_nonce == expected_nonce

    def render_html(self, tpl=None, html=None, context=None):
        if not tpl and not html:
            msg = "Missing template or html parameters"
            raise ValueError(msg)
        context = context or {}
        try:
            template = loader.get_template(tpl)
            return template.render(context=context, request=self.request)
        except (TypeError, TemplateDoesNotExist):
            return render_template_string(self.request, html, context)

    def authenticate(self, backend, **kwargs):
        kwargs["strategy"] = self
        kwargs["storage"] = self.storage
        kwargs["backend"] = backend
        kwargs.pop("request", None)
        return authenticate(self.request, **kwargs)

    def clean_authenticate_args(self, request, *args, **kwargs):
        # pipelines don't want a positional request argument
        kwargs["request"] = request
        return args, kwargs

    def session_get(self, name, default=None):
        return self.session.get(name, default)

    def session_set(self, name, value):
        self.session[name] = value
        if hasattr(self.session, "modified"):
            self.session.modified = True

    def session_pop(self, name):
        return self.session.pop(name, None)

    def session_setdefault(self, name, value):
        return self.session.setdefault(name, value)

    def build_absolute_uri(self, path=None):
        if self.request:
            return self.request.build_absolute_uri(path)
        return path

    def random_string(self, length=12, chars=BaseStrategy.ALLOWED_CHARS):
        return get_random_string(length, chars)

    def to_session_value(self, val):
        """
        Converts values that are instance of Model to a dictionary
        with enough information to retrieve the instance back later.
        """
        if isinstance(val, MultiValueDict):
            val = val.dict()
        elif isinstance(val, Model):
            val = {"pk": val.pk, "ctype": ContentType.objects.get_for_model(val).pk}
        return val

    def from_session_value(self, val):
        """Converts back the instance saved by self._ctype function."""
        if isinstance(val, dict) and "pk" in val and "ctype" in val:
            ctype = ContentType.objects.get_for_id(val["ctype"])
            model_class = ctype.model_class()
            if model_class is None:
                msg = f"Content type {ctype.pk} does not reference a model"
                raise TypeError(msg)
            val = model_class._default_manager.get(pk=val["pk"])  # noqa: SLF001

        return val

    def get_language(self):
        """Return current language"""
        return get_language()

    def get_session_id(self) -> str | None:
        if self.session.session_key is None:
            self.session.create()
        return self.session.session_key

    def restore_session(self, session_id: str, kwargs: dict[str, Any]) -> None:
        request = self._require_request()
        # Load session
        request.session = self.session = create_session(session_id)
        # Update request user
        request.user = get_user(request)
        if "user" in kwargs and request.user.is_authenticated:
            kwargs["user"] = request.user
        # Rotate session key to avoid reuse
        self.session.cycle_key()
