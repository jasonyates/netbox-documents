"""Strawberry is a Python library for GraphQL.

Strawberry is a Python library for GraphQL that aims to stay close to the GraphQL
specification and allow for a more natural way of defining GraphQL schemas.
"""

from typing import TYPE_CHECKING

from . import experimental, federation, relay
from .directive import directive, directive_field
from .parent import Parent
from .permission import BasePermission
from .scalars import ID
from .schema import ExceptionHandler, Schema
from .schema_directive import schema_directive
from .streamable import Streamable
from .types.arguments import argument
from .types.auto import auto
from .types.cast import cast
from .types.enum import enum, enum_value
from .types.field import field
from .types.info import Info
from .types.lazy_type import LazyType, lazy
from .types.maybe import Maybe, Some
from .types.mutation import mutation, subscription
from .types.object_type import asdict, input, interface, type  # noqa: A004
from .types.private import Private
from .types.scalar import scalar
from .types.union import union
from .types.unset import UNSET

if TYPE_CHECKING:
    from . import pydantic as pydantic
else:
    # hidden from type checkers, which would otherwise accept any attribute of
    # the module
    def __getattr__(name: str) -> object:
        # `strawberry.pydantic` depends on the optional pydantic package, so we
        # only import it on first access instead of when importing strawberry
        if name == "pydantic":
            import importlib

            try:
                return importlib.import_module(f"{__name__}.pydantic")
            except ImportError as exc:
                # an AttributeError keeps `hasattr` and `getattr` with a default
                # working when pydantic isn't installed
                raise AttributeError(str(exc)) from exc

        raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


__all__ = [
    "ID",
    "UNSET",
    "BasePermission",
    "ExceptionHandler",
    "Info",
    "LazyType",
    "Maybe",
    "Parent",
    "Private",
    "Schema",
    "Some",
    "Streamable",
    "argument",
    "asdict",
    "auto",
    "cast",
    "directive",
    "directive_field",
    "enum",
    "enum_value",
    "experimental",
    "federation",
    "field",
    "input",
    "interface",
    "lazy",
    "mutation",
    "relay",
    "scalar",
    "schema_directive",
    "subscription",
    "type",
    "union",
]
